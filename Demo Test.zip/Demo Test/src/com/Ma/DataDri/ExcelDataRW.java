/**
 * 
 */
package com.Ma.DataDri;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;



import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



/**
 * @author ZuCxX
 *
 */
public class ExcelDataRW {

	XSSFSheet XSSFSh;
	FileOutputStream FOS;
	FileInputStream FIS;
	/**
	 * @param filePath
	 * @param sheetName
	 * @throws IOException 
	 */
	public ExcelDataRW(String r_w, String filePath, String sheetName) throws IOException {
		if (r_w.equals("r") || r_w.equals("R")) {
			FIS = new FileInputStream(filePath);
			XSSFWorkbook XSSFWB = new XSSFWorkbook(FIS);
			XSSFSh = XSSFWB.getSheet(sheetName);
		}
		else if (r_w.equals("w") || r_w.equals("W")) {
			XSSFWorkbook XSSFWB = new XSSFWorkbook();
			FOS = new FileOutputStream(filePath);
			XSSFWB.write(FOS);
			XSSFSh = XSSFWB.getSheet(sheetName);
		}
	}
	
	public String ReadData (int row, int col) throws IOException {
		XSSFRow Row = XSSFSh.getRow(row);
		XSSFCell Cell = Row.getCell(col);
		if (Cell.getCellType() == XSSFCell.CELL_TYPE_STRING) {
			FIS.close();
			return Cell.getStringCellValue();
		}
		else {
			FIS.close();
			return (""+Cell.getNumericCellValue()).substring(0, (""+Cell.getNumericCellValue()).length()-2);
		}
	}
	
	public void WriteData (int row, int col, String data) throws IOException {
		XSSFRow Row = XSSFSh.getRow(row);
		XSSFCell Cell = Row.getCell(col);
		Cell.setCellValue(data);
		FOS.close();
	}
}
