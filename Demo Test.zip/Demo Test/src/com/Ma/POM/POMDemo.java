/**
 * 
 */
package com.Ma.POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

/**
 * @author ZuCxX
 *
 */
public class POMDemo {

	WebDriver driver;
	Select select;
	public static String Path = "F://Java//Home Prac//Demo Test//src//TestData.xlsx";
	public static String SheetNam = "Sheet1";
		
		@FindBy(className="caret")
		WebElement MyAccount;
		
		@FindBy(xpath="/html/body/nav/div/div[2]/ul/li[2]/ul/li[1]/a")
		WebElement Register;
		
		@FindBy(id="input-firstname")
		WebElement FirstName;
		
		@FindBy(id="input-lastname")
		WebElement LastName;
		
		@FindBy(id="input-email")
		WebElement EmailId;
		
		@FindBy(id="input-telephone")
		WebElement TelePhone;
		
		@FindBy(id="input-fax")
		WebElement FaxNo;
		
		@FindBy(id="input-company")
		WebElement Company;
		
		@FindBy(id="input-address-1")
		WebElement Address1;
		
		@FindBy(id="input-address-2")
		WebElement Address2;
		
		@FindBy(id="input-city")
		WebElement City;
		
		@FindBy(id="input-postcode")
		WebElement PostCode;
		
		@FindBy(tagName="h1")
		WebElement Title;
		
		@FindBy(id="input-country")
		WebElement CountryName;
		
		@FindBy(id="input-zone")
		WebElement StateSelect;
		
		@FindBy(id="input-password")
		WebElement Password;
		
		@FindBy(id="input-confirm")
		WebElement CnfrmPassword;
		
		@FindBy(xpath="/html/body/div[2]/div/div/form/div/div/input[1]")
		WebElement AcceptAgree;
		
		@FindBy(xpath="/html/body/div[2]/div/div/form/div/div/input[2]")
		WebElement ConntinueClick;

		
		
		@FindBy(xpath="/html/body/div[2]/div[2]/div/form/fieldset[1]/div[2]/div/div")
		WebElement FirsNamErr;
		
		/**
		 * @param driver
		 */
		public POMDemo(WebDriver driver) {
			this.driver = driver;
			
			//This initElements method will create all WebElements
	        PageFactory.initElements(driver, this);
		}

		public void registerClick() {
			MyAccount.click();
			Register.click();
		}
		
		public void setFirstName(String FirstNam) {
			FirstName.clear();
			FirstName.sendKeys(FirstNam);
		}
		
		public void setLastName(String LastNam) {
			LastName.clear();
			LastName.sendKeys(LastNam);
		}
		
		public void setEmailId(String EmailIDD) {
			EmailId.clear();
			EmailId.sendKeys(EmailIDD);
		}
		
		public void setfax(String fax) {
			FaxNo.clear();
			FaxNo.sendKeys(fax);
		}
		
		public void setTelephone(String Tele) {
			TelePhone.clear();
			TelePhone.sendKeys(Tele);
		}
		
		public void setCompany(String companyName) {
			Company.clear();
			Company.sendKeys(companyName);
		}
		
		public void setAddress1(String Address) {
			Address1.clear();
			Address1.sendKeys(Address);
		}
		
		public void setAddress2(String Address) {
			Address2.clear();
			Address2.sendKeys(Address);
		}
		
		public void setCity(String cityName) {
			City.clear();
			City.sendKeys(cityName);
		}
		
		public void setPostcode(String PostCde) {
			PostCode.clear();
			PostCode.sendKeys(PostCde);
		}
		
		public void setCountry(String CountryNam) {
			select  = new Select(this.CountryName);
			select.selectByVisibleText(CountryNam);
		}
		
		public void setState(String StateName) {
			select  = new Select(StateSelect);
			select.selectByVisibleText(StateName);
		}
		
		public String PageTitle() {
			return Title.getText();
		}
		
		public void setPassword(String Passwrd) {
			Password.clear();
			Password.sendKeys(Passwrd);
		}
		
		public void setCnfrmPswrd(String CnfrmPasswrd) {
			CnfrmPassword.clear();
			CnfrmPassword.sendKeys(CnfrmPasswrd);
		}
		
		public void AcceptAgreement() {
			if (!AcceptAgree.isSelected()) {
				AcceptAgree.click();
			}
		}
		
		public void continueClick() {
			ConntinueClick.click();
		}
		
		public String FrstErr() {
			return FirsNamErr.getText();
		}
}
