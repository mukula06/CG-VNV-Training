/**
 * 
 */
package com.Ma.dao;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

import com.Ma.DataDri.*;
import com.Ma.POM.*;

/**
 * @author ZuCxX
 *
 */
public class RegistrationForm {

	public void RegistrationFill (int row, int col, POMDemo page, WebDriver driver) throws IOException {
		ExcelDataRW EDR = new ExcelDataRW("r", POMDemo.Path, POMDemo.SheetNam);
		page.setFirstName(EDR.ReadData(row, col));
		row++;
		page.setLastName(EDR.ReadData(row, col));
		row++;
		page.setEmailId(EDR.ReadData(row, col));
		row++;
		page.setTelephone(EDR.ReadData(row, col));
		row++;
		page.setfax(EDR.ReadData(row, col));
		row++;
		page.setCompany(EDR.ReadData(row, col));
		row++;
		page.setAddress1(EDR.ReadData(row, col));
		page.setAddress2(EDR.ReadData(row, col));
		row++;
		page.setCity(EDR.ReadData(row, col));
		row++;
		page.setPostcode(EDR.ReadData(row, col));
		row++;
		page.setCountry("India");
		row++;
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page.setState("Rajasthan");
		row++;
		page.setPassword(EDR.ReadData(row, col));
		row++;
		page.setCnfrmPswrd(EDR.ReadData(row, col));
		
		page.AcceptAgreement();
		page.continueClick();
		
		
	}
}
