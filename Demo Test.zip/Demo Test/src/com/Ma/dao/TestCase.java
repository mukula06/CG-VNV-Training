/**
 * 
 */
package com.Ma.dao;

import java.io.IOException;
import java.sql.Driver;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.Ma.POM.*;
import com.Ma.DataDri.*;

/**
 * @author ZuCxX
 *
 */
public class TestCase {

	WebDriver driver;
	POMDemo page;
	RegistrationForm RFFill;
	ExcelDataRW EDR;
	
	
	
	@BeforeMethod
	public void config() throws IOException {
		System.setProperty("webdriver.chrome.driver", "F://Java//Driver//chromedriver_win32//chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://demo.opencart.com");
		page = new POMDemo(driver);
		page.registerClick();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		RFFill = new RegistrationForm();
	}
	
	@Test(priority=0)
	public void TC_01() throws IOException {
		RFFill.RegistrationFill(0, 1, page, driver);
		Assert.assertEquals("", "");
	}
	
	@Test(priority=1)
	public void TC_02() throws IOException {
		RFFill.RegistrationFill(0, 2, page, driver);
		Assert.assertEquals("", "");
	}
	
	@Test(priority=2)
	public void TC_03() throws IOException {
		RFFill.RegistrationFill(0, 3, page, driver);
		Assert.assertEquals(page.FrstErr(), "First Name must be between 1 and 32 characters!");
	}
	
	@Test(priority=3)
	public void TC_04() throws IOException {
		RFFill.RegistrationFill(0, 4, page, driver);
		Assert.assertEquals("", "");
	}
	
	@AfterMethod
	public void closeDri() throws InterruptedException {
		Thread.sleep(5000);
		driver.quit();
	}
}
