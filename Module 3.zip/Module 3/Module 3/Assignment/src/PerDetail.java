
public class PerDetail {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Personal Details:");
		System.out.println("__________________");
		System.out.println("First Name: Divya");
		System.out.println("Last Name: Bharathi");
		System.out.println("Gender: F\nAge: 20\nWeight: 85.55");
	}

}
