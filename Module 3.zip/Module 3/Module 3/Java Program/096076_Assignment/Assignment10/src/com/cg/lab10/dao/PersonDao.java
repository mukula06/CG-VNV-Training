package com.cg.lab10.dao;

import java.util.List;

import com.cg.lab10.dto.PersonProperties;
import com.cg.lab10.exception.PersonException;

/**
 * 
 * @author pmandawa
 *
 */
public interface PersonDao {
	/**
	 * 
	 * @param properties
	 */
	public void addDetails(PersonProperties properties);

	/**
	 * 
	 * @return
	 * @throws PersonException
	 */
	public List<PersonProperties> showData() throws PersonException;

	/**
	 * 
	 * @param properties
	 * @return
	 */
	public PersonProperties search(PersonProperties properties);

	/**
	 * 
	 * @param properties
	 * @return
	 */
	public PersonProperties deleteData(PersonProperties properties);

}
