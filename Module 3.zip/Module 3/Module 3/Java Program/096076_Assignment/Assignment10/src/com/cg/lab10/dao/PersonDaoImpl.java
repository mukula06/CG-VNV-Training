package com.cg.lab10.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.lab10.dto.PersonProperties;
import com.cg.lab10.exception.PersonException;
import com.cg.lab10.util.DbUtil;

/**
 * 
 * @author pmandawa
 *
 */
public class PersonDaoImpl implements PersonDao {

	@Override
	public void addDetails(PersonProperties properties) {
		Connection con = null;
		try {
			con = DbUtil.getConnection();

			String query = "INSERT INTO PERSONDETAILS VALUES(?,?,?,?,?)";
			PreparedStatement pstm = con.prepareStatement(query);
			pstm.setString(1, properties.getName());
			pstm.setInt(2, properties.getAge());
			pstm.setDouble(3, properties.getSalary());
			pstm.setString(4, properties.getCompany());
			pstm.setString(5, properties.getDesignation());
			System.out.println("Output.........");
			int status = pstm.executeUpdate();
			if (status == 1) {
				System.out.println("data inserted.......");
			}
		} catch (PersonException | SQLException e) {

			e.printStackTrace();
			System.out.println("Problem in inserting data......");
		} finally {
			try {
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

	}

	/**
	 * 
	 * @see com.cg.lab10.dao.PersonDao#showData()
	 */
	@Override
	public List<PersonProperties> showData() throws PersonException {
		List<PersonProperties> myList = new ArrayList<PersonProperties>();
		Connection conn = null;

		try {
			conn = DbUtil.getConnection();
			String query2 = "SELECT * FROM PERSONDETAILS";
			Statement stm = conn.createStatement();
			ResultSet set = stm.executeQuery(query2);
			while (set.next()) {
				PersonProperties per = new PersonProperties();
				per.setName(set.getString("Name"));
				per.setAge(set.getInt("Age"));
				per.setSalary(set.getDouble("Salary"));
				per.setCompany(set.getString("Company"));
				per.setDesignation(set.getString("Designation"));

				myList.add(per);

			}
			System.out.println("Enter ");
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		return myList;
	}

	/**
	 * 
	 * @see com.cg.lab10.dao.PersonDao#search(com.cg.lab10.dto.PersonProperties)
	 */
	@Override
	public PersonProperties search(PersonProperties properties) {
		Connection conn1 = null;
		PersonProperties per = new PersonProperties();

		try {

			conn1 = DbUtil.getConnection();

			String query3 = "SELECT * FROM PERSONDETAILS WHERE Designation = ?";

			PreparedStatement pst = conn1.prepareStatement(query3);
			pst.setString(1, properties.getDesignation());

			ResultSet res = pst.executeQuery();

			while (res.next()) {
				per.setName(res.getString("Name"));
				per.setAge(res.getInt("Age"));
				per.setSalary(res.getDouble("Salary"));
				per.setCompany(res.getString("Company"));
				per.setDesignation(res.getString("Designation"));

			}
		} catch (PersonException | SQLException e) {

			e.printStackTrace();

		} finally {
			try {
				conn1.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}

		}
		return per;
	}

	/**
	 *
	 * @see com.cg.lab10.dao.PersonDao#deleteData(com.cg.lab10.dto.PersonProperties)
	 */
	@Override
	public PersonProperties deleteData(PersonProperties properties) {
		Connection connect = null;
		PersonProperties per2 = new PersonProperties();

		try {
			connect = DbUtil.getConnection();
			String query4 = "DELETE FROM PERSONDETAILS WHERE Designation = ?";
			PreparedStatement pst = connect.prepareStatement(query4);
			pst.setString(1, properties.getDesignation());
			ResultSet res = pst.executeQuery();

			while (res.next()) {
				per2.setName(res.getString("Name"));
				per2.setAge(res.getInt("Age"));
				per2.setSalary(res.getDouble("Salary"));
				per2.setCompany(res.getString("Company"));
				per2.setDesignation(res.getString("Designation"));
				break;

			}
		} catch (PersonException | SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				connect.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		return properties;
	}

}