package com.cg.lab10.exception;

public class PersonException extends Exception {

	/**
	 * @author pmandawa
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Default Constructor
	 */
	public PersonException() {
		super();
	}

	/**
	 * 
	 * @param message
	 */
	public PersonException(String message) {
		super(message);
	}

}
