package com.cg.lab10.service;

import java.util.List;

import com.cg.lab10.dao.PersonDao;
import com.cg.lab10.dao.PersonDaoImpl;
import com.cg.lab10.dto.PersonProperties;
import com.cg.lab10.exception.PersonException;

public class PersonServiceImpl implements PersonService {
	PersonDao personDao = new PersonDaoImpl();

	@Override
	public void addDetails(PersonProperties properties) {
		personDao.addDetails(properties);

	}

	@Override
	public List<PersonProperties> showData() throws PersonException {

		return personDao.showData();
	}

	@Override
	public PersonProperties search(PersonProperties properties) {
		return personDao.search(properties);

	}

	@Override
	public PersonProperties deleteData(PersonProperties properties) {

		return personDao.deleteData(properties);
	}

}
