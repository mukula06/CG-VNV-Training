package com.cg.lab10.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.lab10.dto.PersonProperties;
import com.cg.lab10.exception.PersonException;
import com.cg.lab10.service.PersonService;
import com.cg.lab10.service.PersonServiceImpl;

/**
 * 
 * @author pmandawa
 *
 */
public class PersonTest {

	public static void main(String[] args) {
		int choice = 0;
		PersonService propertiesService = new PersonServiceImpl();
		Scanner sc = new Scanner(System.in);

		do {
			selectChoice();
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter name: ");
				String name = sc.next();
				System.out.println("Enter age :");
				int age = sc.nextInt();
				System.out.println("Enter salary");
				double sal = sc.nextDouble();
				System.out.println("Enter company");
				String comp = sc.next();
				System.out.println("Enter designation");
				String desg = sc.next();

				PersonProperties pers = new PersonProperties();
				pers.setName(name);
				pers.setAge(age);
				pers.setSalary(sal);
				pers.setCompany(comp);
				pers.setDesignation(desg);
				propertiesService.addDetails(pers);
				break;

			case 2:
				List<PersonProperties> showData;
				try {
					showData = propertiesService.showData();

					for (PersonProperties p2 : showData) {
						System.out.println("Name :" + p2.getName());
						System.out.println("Age :" + p2.getAge());
						System.out.println("Salary :" + p2.getSalary());
						System.out.println("Company :" + p2.getCompany());
						System.out.println("Designation :"
								+ p2.getDesignation());

					}
				} catch (PersonException e) {

					e.printStackTrace();
				}
				break;

			case 3:
				System.out.println("Enter the designation to be searched");
				String desig = sc.next();
				PersonProperties persond = new PersonProperties();
				persond.setDesignation(desig);
				persond = propertiesService.search(persond);
				System.out.println("Name :" + persond.getName());
				System.out.println("Age :" + persond.getAge());
				System.out.println("Salary :" + persond.getSalary());
				System.out.println("Comapny :" + persond.getCompany());
				System.out.println("Designation :" + persond.getDesignation());
				break;

			case 4:
				System.out.println("Enter the designation");
				String design = sc.next();
				PersonProperties person = new PersonProperties();
				person.setDesignation(design);
				person = propertiesService.deleteData(person);
				System.out.println("Data Deleted");
				break;

			case 5:
				System.exit(0);
				break;

			}
		} while (choice != 5);
		sc.close();

	}

	public static void selectChoice() {
		System.out.println("Enter your choice ");
		System.out.println("1: Add");
		System.out.println("2: Show");
		System.out.println("3: Search");
		System.out.println("4: Delete");
		System.out.println("5: Exit");
	}
}
