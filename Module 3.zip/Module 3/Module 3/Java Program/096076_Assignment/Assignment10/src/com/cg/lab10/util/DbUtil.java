package com.cg.lab10.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.lab10.exception.PersonException;



public class DbUtil {
	static Connection con = null;
	public static Connection getConnection() throws PersonException
	{
		try {
		FileInputStream fileRead = new FileInputStream("PersonProps.properties");
		Properties prop = new Properties();
		prop.load(fileRead);
		
		String driver  = prop.getProperty("oracle.driver");
		
		String url = prop.getProperty("oracle.url");
		String username  = prop.getProperty("oracle.username");
		String pswrd = prop.getProperty("oracle.password");
		
		Class.forName(driver);
		con = DriverManager.getConnection(url, username, pswrd);
		
		
		System.out.println("Connection established");
		
			} catch (SQLException | IOException |ClassNotFoundException e ) {
				e.printStackTrace();
				throw new PersonException("Connection not established");
				
			}
			
		return con;
	}
}
