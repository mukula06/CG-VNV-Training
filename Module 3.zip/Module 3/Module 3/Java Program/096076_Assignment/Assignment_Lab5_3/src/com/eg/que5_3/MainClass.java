package com.eg.que5_3;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);

		Person acc = new Account();
		Account person1 = (Account) acc;

		// Person1 Object

		Person smith = new Person();
		smith.setName("Smith");
		smith.setAge(21);

		person1.setAccHolder(smith);
		person1.setBalance(2000);
		long accNum = person1.generateAccNum();
		person1.setAccNum(accNum);
		person1.deposite(2000);
		person1.displayDetails();

		// Person2 Object

		Account person2 = (Account) acc;
		Person kathy = new Person();
		kathy.setName("Kathy");
		kathy.setAge(21);

		person2.setAccHolder(kathy);
		person2.setBalance(3000);
		long accNum2 = person2.generateAccNum();
		person2.setAccNum(accNum2);
		boolean isWithdrawl = person2.withDraw(2000);
		if (isWithdrawl) {
			System.out.println("Your Transaction Has Been Done Your Details Are :-");
			person2.displayDetails();
		}
		else {
			System.out.println("You Have Entered Invalid Amount");
		}
		
		
		ss.close();

	}

}
