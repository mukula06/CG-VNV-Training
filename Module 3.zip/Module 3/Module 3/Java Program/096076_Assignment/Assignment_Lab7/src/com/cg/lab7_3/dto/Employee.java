package com.cg.lab7_3.dto;

public class Employee {
	private int Id;
	private String Name;
	private double Salary;
	private String designation;
	private String insuranceScheme;
	/**
	 * 
	 */
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param id
	 * @param name
	 * @param salary
	 * @param designation
	 * @param insuranceScheme
	 */
	public Employee(int id, String name, double salary, String designation,
			String insuranceScheme) {
		super();
		Id = id;
		Name = name;
		Salary = salary;
		this.designation = designation;
		this.insuranceScheme = insuranceScheme;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Employee [Id=" + Id + ", Name=" + Name + ", Salary=" + Salary
				+ ", designation=" + designation + ", insuranceScheme="
				+ insuranceScheme + "]";
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return Id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		Id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return Name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		Name = name;
	}
	/**
	 * @return the salary
	 */
	public double getSalary() {
		return Salary;
	}
	/**
	 * @param salary the salary to set
	 */
	public void setSalary(double salary) {
		Salary = salary;
	}
	/**
	 * @return the designation
	 */
	public String getDesignation() {
		return designation;
	}
	/**
	 * @param designation the designation to set
	 */
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	/**
	 * @return the insuranceScheme
	 */
	public String getInsuranceScheme() {
		return insuranceScheme;
	}
	/**
	 * @param insuranceScheme the insuranceScheme to set
	 */
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}

	
	
}