package com.cg.lab7_3.service;

import java.util.HashMap;

import com.cg.lab7_3.dto.Employee;
/**
 * 
 * @author pmandawa
 *
 */
public interface EmployeeService {
	/**
	 * 
	 * @return
	 */
	public String SchemeC();
	/**
	 * 
	 * @return
	 */
	public String SchemeB();
	/**
	 * 
	 * @return
	 */
	public String SchemeA();
	/**
	 * 
	 * @param emp
	 */
	public void addEmployee(Employee emp);
	/**
	 * @return void
	 */
	public void SortEmployee();
	/**
	 * 
	 * @param key
	 */
	public void removeEmployee(String key);
	/**
	 * 
	 * @return
	 */
	public HashMap<String, Employee> showAll();
}
