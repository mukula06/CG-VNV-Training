package com.cg.lab7_3.service;


import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;




import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.cg.lab7_3.dto.Employee;



public class EmployeeServiceImpl implements EmployeeService {
	public EmployeeServiceImpl(){

	}
	HashMap<String,Employee> list= new HashMap<String,Employee>();
	@Override
	public String SchemeC() {
		return "Employee eligible for Medical Insurance";

	}

	@Override
	public String SchemeB() {
		return "Employee eligible for life Insurance";

	}

	@Override
	public String SchemeA() {
		return "Employee eligible for car Insurance";

	}
	public String insurancescheme() {
		Employee e = new Employee();
		
		if(e.getSalary()>5000 && e.getSalary()<20000 && (e.getDesignation().equals("System Associate")) ){
			return SchemeC();
			
		}
		else if(e.getSalary()>=20000 && e.getSalary()<40000 && ( e.getDesignation().equals("Programmer") ) ) {

			return SchemeB();
		}
		else if(e.getSalary()>=40000 && ( e.getDesignation().equals("Manager"))){
			
			return SchemeA();
		}
		else
			return "Employee is not eligible for any Scheme";
		
	}

	@Override
	public void addEmployee(Employee emp) {
		list.put(emp.getName(), emp);
		
		
	}

	@Override
	public void SortEmployee() {

	  }
	
	@Override
	public HashMap<String, Employee> showAll() {
		// TODO Auto-generated method stub
		return this.list;
	}

	@Override
	public void removeEmployee(String key) {
		// TODO Auto-generated method stub
		 list.remove(key);
	}
	
	

	



}
