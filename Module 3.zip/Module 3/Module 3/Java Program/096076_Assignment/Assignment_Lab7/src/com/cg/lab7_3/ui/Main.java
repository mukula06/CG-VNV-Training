package com.cg.lab7_3.ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

import com.cg.lab7_3.dto.Employee;
import com.cg.lab7_3.service.EmployeeService;
import com.cg.lab7_3.service.EmployeeServiceImpl;
/**
 * 
 * @author pmandawa
 *
 */
public class Main {
	public static void main(String[] args) {

		int choice = 0;
		EmployeeService s = new EmployeeServiceImpl();
		HashMap<String, Employee> list = new HashMap<String, Employee>();
		do {

			Scanner scr = new Scanner(System.in);
			printDetails();
			System.out.println("enter the choice: ");
			choice = scr.nextInt();
			switch (choice) {
			case 1:
				Employee e = new Employee();
				System.out.println("Enter the Id: ");
				int eId = scr.nextInt();
				System.out.println("Enter Name: ");
				String Name = scr.next();
				System.out.println("Enter Salary: ");
				double sal = scr.nextDouble();
				System.out.println("Enter the designation: ");
				String designation = scr.next();
				System.out.println("Enter Insurance Scheme: ");
				String insurance = scr.next();
				e.setId(eId);
				e.setName(Name);
				e.setSalary(sal);
				e.setDesignation(designation);
				e.setInsuranceScheme(insurance);
				s.addEmployee(e);
				break;

			case 2:
				HashMap<String, Employee> list1 = s.showAll();

				for (Employee emp : list1.values()) {
					System.out.println("ID is :" + emp.getId());
					System.out.println("Name is:" + emp.getName());
					System.out.println("Salary is: " + emp.getSalary());
					System.out.println("Designation is: "
							+ emp.getDesignation());
					System.out.println("Insurance scheme is: "
							+ emp.getInsuranceScheme());
				}
				break;

			case 3:
				System.out.println("Enter the employee name to be removed: ");
				String name = scr.next();
				s.removeEmployee(name);
				break;

			case 4:
				HashMap<String, Employee> map = s.showAll();

				List<Employee> list3 = new ArrayList<Employee>(map.values());

				for (Employee employee : list3) {
					System.out.println("ID is :" + employee.getId());
					System.out.println("Name is:" + employee.getName());
					System.out.println("Salary is: " + employee.getSalary());
					System.out.println("Designation is: "
							+ employee.getDesignation());
					System.out.println("InsuranceScheme is: "
							+ employee.getInsuranceScheme());
				}
				break;
			}
		} while (choice != 5);
	}

	public static void printDetails() {
		System.out.println("*****Employee Details********");
		System.out.println("1. Add Employee");
		System.out.println("2. Show Details ");
		System.out.println("3. Remove Employee");
		System.out.println("4. Sort");
		System.out.println("5. Exit");
	}
}
