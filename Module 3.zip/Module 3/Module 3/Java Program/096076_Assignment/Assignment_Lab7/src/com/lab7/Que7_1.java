package com.lab7;

import java.util.Arrays;
import java.util.Scanner;

public class Que7_1 {
	
	public static void main(String[] args) {
		String str[] = new String[10];;
		Scanner sc = new Scanner(System.in);
		for(int i=0;i<str.length;i++){
			str[i]=sc.next();
		}
		Arrays.sort(str);

		for(String s:str){
			System.out.println(s);
		}

	}

}
