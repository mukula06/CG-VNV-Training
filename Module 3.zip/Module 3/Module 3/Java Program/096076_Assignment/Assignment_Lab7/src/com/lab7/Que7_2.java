package com.lab7;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Que7_2 {
	
	public static void main(String[] args) {
		List<String>list = new ArrayList<String>();

		System.out.println("Enter the size of the list: ");
		Scanner inputsize = new Scanner(System.in);
		int listsize = inputsize.nextInt();

		System.out.println("Enter the products: ");
		Scanner sc = new Scanner(System.in);

		for(int i=0;i<listsize;i++){
			list.add(sc.next());
		}

		System.out.println("The Products Entered are:");
		for(String i:list ){
			System.out.println(i);
		}

		Collections.sort(list);
		System.out.println("The sorted products are: ");
		for(String i:list ){
			System.out.println(i);
		}




	}


}
