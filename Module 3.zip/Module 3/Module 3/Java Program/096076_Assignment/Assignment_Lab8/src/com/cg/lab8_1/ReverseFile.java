package com.cg.lab8_1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * 
 * @author pmandawa
 *
 */
public class ReverseFile {

	public static void main(String[] args) {
		FileReader fileReader = null;
		BufferedReader bufferReader = null;
		FileWriter fileWriter = null;
		BufferedWriter bufferWriter = null;
		try {
			fileReader = new FileReader("Input.txt");
			bufferReader = new BufferedReader(fileReader);
			fileWriter = new FileWriter("Output.txt");
			bufferWriter = new BufferedWriter(fileWriter);
			String s;
			while ((s = bufferReader.readLine()) != null) {
				System.out.println(s);
				String[] words = s.split(" ");
				for (String s1 : words) {
					StringBuilder builder = new StringBuilder(s1);
					bufferWriter.write(builder.reverse().toString());

				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				bufferReader.close();
				bufferWriter.close();
			} catch (IOException e) {
		
				e.printStackTrace();
			}

		}
	}

}
