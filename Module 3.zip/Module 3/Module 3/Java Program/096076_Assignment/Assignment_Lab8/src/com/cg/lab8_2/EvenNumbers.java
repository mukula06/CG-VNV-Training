package com.cg.lab8_2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/**
 * 
 * @author pmandawa
 *
 */
public class EvenNumbers {

	public static void main(String[] args) {
		
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream("InputNumber.txt");
			Scanner sc = new Scanner(fileInput).useDelimiter(",");

			while (sc.hasNextInt()) {

				int check = sc.nextInt();
				if (check % 2 == 0) {

					System.out.println("Even Numbers are: " + check);

				}

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("File Not Found");
		} finally {

			try {
				fileInput.close();
			} catch (IOException e) {
				
				e.printStackTrace();
			}

		}
	}

}
