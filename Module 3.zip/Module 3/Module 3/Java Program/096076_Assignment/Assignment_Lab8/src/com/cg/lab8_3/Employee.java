package com.cg.lab8_3;

/**
 * 
 * @author pmandawa
 *
 */
public class Employee {

	
	private int empId;
	private String empName;
	private double empSalary;
	private String empDsignation;
	private String insuranceScheme;
	
	/**
	 * 
	 */
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param empId
	 * @param empName
	 * @param empSalary
	 * @param empDsignation
	 * @param insuranceScheme
	 */
	public Employee(int empId, String empName, double empSalary,
			String empDsignation, String insuranceScheme) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empDsignation = empDsignation;
		this.insuranceScheme = insuranceScheme;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", empSalary=" + empSalary + ", empDsignation="
				+ empDsignation + ", insuranceScheme=" + insuranceScheme + "]";
	}

	/**
	 * @return the empId
	 */
	public int getEmpId() {
		return empId;
	}

	/**
	 * @param empId the empId to set
	 */
	public void setEmpId(int empId) {
		this.empId = empId;
	}

	/**
	 * @return the empName
	 */
	public String getEmpName() {
		return empName;
	}

	/**
	 * @param empName the empName to set
	 */
	public void setEmpName(String empName) {
		this.empName = empName;
	}

	/**
	 * @return the empSalary
	 */
	public double getEmpSalary() {
		return empSalary;
	}

	/**
	 * @param empSalary the empSalary to set
	 */
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}

	/**
	 * @return the empDsignation
	 */
	public String getEmpDsignation() {
		return empDsignation;
	}

	/**
	 * @param empDsignation the empDsignation to set
	 */
	public void setEmpDsignation(String empDsignation) {
		this.empDsignation = empDsignation;
	}

	/**
	 * @return the insuranceScheme
	 */
	public String getInsuranceScheme() {
		return insuranceScheme;
	}

	/**
	 * @param insuranceScheme the insuranceScheme to set
	 */
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	
	
	
}
