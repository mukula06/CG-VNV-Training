package com.cg.lab8_3;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * 
 * @author pmandawa
 *
 */
public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee = new Employee(1001, "Prathu", 25000, "SE",
				"A");
		try {
			FileOutputStream fileOutput = new FileOutputStream("Employee.txt");
			ObjectOutputStream objectOutput = new ObjectOutputStream(fileOutput);
			objectOutput.writeObject(employee);
			objectOutput.flush();
			objectOutput.close();
		} catch (IOException e) {
			System.out.println("File cannot be written......");
		}
		try {

			FileInputStream fileInput = new FileInputStream("Employee.txt");
			ObjectInputStream objectInput = new ObjectInputStream(fileInput);
			Employee emp = (Employee) objectInput.readObject();
			objectInput.close();
			System.out.println("Employee is: " + emp);
		} catch (IOException | ClassNotFoundException e) {
			System.out.println("File cannot be read......");
		}
	}

}
