package lab_2;

/**
 * @author pmandawa
 *
 */

import java.util.Scanner;

public class Que1_Person_Details {

	public static void main(String[] args) {
		
		Scanner ss = new Scanner(System.in);

		// Taking Inputs...

		System.out.println("Please Enter Your First Name : - ");
		String firstName = ss.nextLine();

		System.out.println("Please Enter Your Last Name : - ");
		String lastName = ss.nextLine();

		System.out.println("Please Enter 'F' for Female And 'M' For Male : - ");
		String gender = ss.next();

		System.out.println("Enter Your Age : - ");
		int age = ss.nextInt();

		System.out.println("Enter Your Weight : - ");
		double weight = ss.nextDouble();

		ss.close();

		// Now Print All The Details...

		System.out.println("Person Details");
		System.out.println("...........................");
		System.out.println("First Name : " + firstName);
		System.out.println("Last Name : " + lastName);
		System.out.println("Gender : " + gender);
		System.out.println("Age : " + age);
		System.out.println("Weight : " + weight);

		
		

	}

}
