package lab_2;

/**
 * @author pmandawa
 *
 */

public class Que2_Check_Positive_Negative {

	public static void main(String[] args) {
		
		long inputNum = Integer.parseInt(args[0]);
		
		if (inputNum >= 0) {
			System.out.println("Number Is Positive");
		}
		else {
			System.out.println("Number Is Negative");
		}

	}

}
