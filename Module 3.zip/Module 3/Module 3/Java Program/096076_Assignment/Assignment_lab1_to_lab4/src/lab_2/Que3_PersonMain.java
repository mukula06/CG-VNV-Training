/**
 * 
 */
package lab_2;

/**
 * @author pmandawa
 *
 */
public class Que3_PersonMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Que3_Person person = new Que3_Person("Prathu", "Mandawariya", 'M');
		
		// Now Print All The Details...

		System.out.println("Person Details");
		System.out.println("...........................");
		System.out.println("First Name : " + person.getFirstName());
		System.out.println("Last Name : " + person.getLastName());
		System.out.println("Gender : " + person.getGender());
		
	}

}
