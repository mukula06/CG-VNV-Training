/**
 * 
 */
package lab_2;

import java.util.Scanner;

/**
 * @author pmandawa
 *
 */
public class Que4_PersonMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		Que4_Person person = new Que4_Person("Prathu", "Mandawariya", 'M');
		
		System.out.println("Please Enter Your Phone Number : - ");
		long phn_num = ss.nextLong();
		
		person.setPhn_num(phn_num);
		person.displayDetails();
		
		ss.close();	
	}

}
