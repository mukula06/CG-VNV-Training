package lab_2;

import lab_2.Que5_PersonMain.Gender;

/**
 * @author pmandawa
 *
 */

public class Que5_Person {

	private String firstName;
	private String lastName;
	private Gender gender;
	private long phn_num;

	/**
	 * 
	 */
	public Que5_Person() {
		super();
	}

	
	
	
	/**
	 * @param firstName
	 * @param lastName
	 * @param gender
	 * @param phn_num
	 */
	public Que5_Person(String firstName, String lastName, Gender gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}




	public void displayDetails() {
		System.out.println("Person Details");
		System.out.println("...........................");
		System.out.println("First Name : " + this.getFirstName());
		System.out.println("Last Name : " + this.getLastName());
		System.out.println("Gender : " + this.getGender());
		System.out.println("Phone Number : " + this.phn_num);
	}
	

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the gender
	 */
	
	/**
	 * @return the phn_num
	 */
	public long getPhn_num() {
		return phn_num;
	}

	/**
	 * @return the gender
	 */
	public Gender getGender() {
		return gender;
	}

	/**
	 * @param gender the gender to set
	 */
	public void setGender(Gender gender) {
		this.gender = gender;
	}

	/**
	 * @param phn_num the phn_num to set
	 */
	public void setPhn_num(long phn_num) {
		this.phn_num = phn_num;
	}
	
	

}
