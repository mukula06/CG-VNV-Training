/**
 * 
 */
package lab_2;

import java.util.Scanner;

/**
 * @author pmandawa
 *
 */
public class Que5_PersonMain {

	enum Gender { M, F }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		System.out.println("Press 'M' For Male and 'F' for Female : -");
		String gender = ss.next();
		Gender enumGender = null;
		try {
			enumGender = Gender.valueOf(gender);
		}catch (Exception e) {
			System.out.println("You Have Entered Wrong Input For Gender");
			System.exit(0);
		}
		

		Que5_Person person = new Que5_Person("Prathu", "Mandawariya", enumGender);
		
		System.out.println("Please Enter Your Phone Number : - ");
		long phn_num = ss.nextLong();
		
		person.setPhn_num(phn_num);
		person.displayDetails();
		
		ss.close();
	}

}
