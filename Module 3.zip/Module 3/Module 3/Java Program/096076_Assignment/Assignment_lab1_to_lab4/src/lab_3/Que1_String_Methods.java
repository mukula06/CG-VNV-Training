package lab_3;

public class Que1_String_Methods {

	/**
	 * This method is for various String function.
	 * 
	 * @param inputWord
	 * @param operation
	 * @return
	 */
	public String stringOperation(String inputWord, String operation) {

		switch (operation) {

		/**
		 * This Case statement Used To Add String To Itself.
		 */
		case "add": {
			String addedString = inputWord + " " + inputWord;
			return addedString;
		}

		/**
		 * This Case Used To Replace Character At Odd Positions.
		 */
		case "replace": {
			
			String[] inputAry = this.splitToArray(inputWord);
			String output = "";
			for (int i = 0; i < inputAry.length; i++) {

				if (i % 2 != 0) {
					output = output + '#';
				} else {
					output = output + inputAry[i];
				}
			}

			return output;
			
		}

		/**
		 * This Case Is Used To remove Duplicates From String.
		 */
		case "remove": {
			String[] inputAry = this.splitToArray(inputWord);
			String output = "";
			for (int i = 0; i < inputAry.length; i++) {
				for(int j = i; j <inputAry.length-1; j++) {
					if (inputAry[i].equalsIgnoreCase(inputAry[j+1])) {
						inputAry[j+1] = " ";
					}
				}
				
			}
			for(int i = 0; i < inputAry.length; i++) {
				
				if(inputAry[i].equalsIgnoreCase(" ")) {
				}
				else{
					output = output + inputAry[i];
				}
					
				
				
			}
			
			return output.trim();
			
		}

		/**
		 * This Case Used To Change Odd Character To UpperCase.
		 */
		case "change": {

			String[] inputAry = this.splitToArray(inputWord);
			String output = "";
			for (int i = 0; i < inputAry.length; i++) {

				if (i % 2 != 0) {
					String upperCase = inputAry[i].toUpperCase();
					output = output + upperCase;
				} else {
					output = output + inputAry[i];
				}
			}

			return output;
		}

		default: {
			System.out.println("Wrong");
			break;
		}

		}
		return null;

	}

	/**
	 * This methos is used to split String into Array.
	 * 
	 * @param inputValue
	 * @return
	 */
	public String[] splitToArray(String inputValue) {
		String[] inputAry = new String[inputValue.length()];
		for (int i = 0; i < inputValue.length(); i++) {
			inputAry[i] = String.valueOf(inputValue.charAt(i));
		}
		return inputAry;

	}

}
