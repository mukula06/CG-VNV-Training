package lab_3;

import java.util.Scanner;

public class Que1_String_Operation_Main {

	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		
		System.out.println(".......Welcome To String World.......");
		System.out.println("Enter Any Word :- ");
		String inputWord = ss.nextLine();
		System.out.println("Enter Your Choice :- ");
		System.out.println("1. Type 'add' For Add String \n2. Type 'replace' For Replace Odd Position by # \n3. Type"
				+ " 'remove' For Removing Duplicate Character In The String \n4. Type"
				+ " 'change' For Change Odd Characters To Upper Case");
		
		String choice  = ss.next();
		
		Que1_String_Methods opt = new Que1_String_Methods();
		String output = opt.stringOperation(inputWord, choice);
		System.out.println("Output Is : " + output);
		ss.close();
	}

}
