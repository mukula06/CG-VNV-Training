package lab_3;

import java.util.Scanner;

public class Que2_CheckPositive {

	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		Que2_CheckPositiveMethod opt = new Que2_CheckPositiveMethod();

		System.out.println("Please Enter Any Word :- ");
		String inputWord = ss.next();

		boolean isSorted = opt.isSorted(inputWord);

		if (isSorted) {
			System.out.println("Word Is Positive");

		} else {
			System.out.println("Word Is Negative");
		}
		
		ss.close();

	}

}
