package lab_3;

public class Que2_CheckPositiveMethod {

	/**
	 * This Method Used To Find The String is Positive Or not.
	 * 
	 * @param inputWord
	 * @return
	 */
	public boolean isSorted(String inputWord) {
		int counter = 1;
		String[] inputAry = this.splitToArray(inputWord);
		for (int i = 1; i < inputAry.length; i++) {
			if (inputAry[i - 1].compareTo(inputAry[i]) > 0) {
				counter--;
			} else {
				counter++;
			}
		}

		if (counter == inputAry.length) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * This methos is used to split String into Array.
	 * 
	 * @param inputValue
	 * @return
	 */
	public String[] splitToArray(String inputValue) {
		inputValue = inputValue.toLowerCase();
		String[] inputAry = new String[inputValue.length()];
		for (int i = 0; i < inputValue.length(); i++) {
			inputAry[i] = String.valueOf(inputValue.charAt(i));
		}
		return inputAry;

	}

}
