package lab_3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class Que3_ComputeDuration {

	/**
	 * This Method Is Used To Calculate Duration Between Two Dates.
	 * 
	 * @param inputDate
	 */
	public void computeDuration(String inputDate) {

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate oldDate = LocalDate.parse(inputDate, formatter);
		LocalDate currentDate = LocalDate.now();

		Period period = oldDate.until(currentDate);

		if ((period.get(ChronoUnit.DAYS) > 0)
				&& (period.get(ChronoUnit.MONTHS) > 0)
				&& (period.get(ChronoUnit.YEARS) > 0)) {

			System.out.println("Days : " + period.get(ChronoUnit.DAYS));
			System.out.println("Months : " + period.get(ChronoUnit.MONTHS));
			System.out.println("Years : " + period.get(ChronoUnit.YEARS));

		} else {
			System.out
					.println("Your First Date Is Equal Or Greater Then Second Date...");
		}

	}

}
