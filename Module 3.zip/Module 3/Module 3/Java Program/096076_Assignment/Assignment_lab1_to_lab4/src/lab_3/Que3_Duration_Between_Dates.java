package lab_3;

import java.util.Scanner;

public class Que3_Duration_Between_Dates {

	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);

		System.out.println("Please Enter Date In Formate 'dd/mm/yyyy' :- ");
		String inputDate = ss.next();

		Que3_ComputeDuration compute = new Que3_ComputeDuration();
		compute.computeDuration(inputDate);

		ss.close();

	}

}
