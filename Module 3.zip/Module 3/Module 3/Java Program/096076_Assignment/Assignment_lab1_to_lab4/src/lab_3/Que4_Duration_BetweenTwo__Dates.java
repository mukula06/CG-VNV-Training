package lab_3;

import java.util.Scanner;

public class Que4_Duration_BetweenTwo__Dates {

	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);

		System.out.println("Please Enter First Date In Formate 'dd/mm/yyyy' :- ");
		String firstDate = ss.next();
		
		System.out.println("Please Enter Second Date In Formate 'dd/mm/yyyy' :- ");
		String secondDate = ss.next();

		Que4_CalcDuration duration = new Que4_CalcDuration();
		duration.computeDuration(firstDate, secondDate);
		
		ss.close();

	}

}
