package lab_3;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Que5_GetExpiryDate {
	
	/**
	 * This Method Is Used To Find Expiry Date Of Product.
	 * 
	 * @param purchaseDate
	 * @param months
	 * @param years
	 */
	public void calculateExpiryDate(String purchaseDate, long months, long years) {
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate purDate = LocalDate.parse(purchaseDate, formatter);
		purDate = purDate.plusMonths(months);
		purDate = purDate.plusYears(years);
		
		System.out.println("Expiry Date Of Your Product Is : " + purDate);
		
	}

}
