package lab_3;

import java.util.Scanner;

public class Que5_ProductExpiry_Date {

	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		
		System.out.println("Please Enter Your Product"
				+ " Purchase Date In Formate 'dd/mm/yyyy'");
		String purchasedDate = ss.next();
		
		System.out.println("Please Enter Warrantee Period In Months And Years : -");
		System.out.println("Enter Month :- ");
		long months = ss.nextLong();
		System.out.println("Enter Year :- ");
		long year = ss.nextLong();
		
		Que5_GetExpiryDate calcExpDate = new Que5_GetExpiryDate();
		calcExpDate.calculateExpiryDate(purchasedDate, months, year);
		ss.close();

	}

}
