package lab_3;

import java.util.Scanner;

public class Que6_DateOfZoneId {

	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		
		System.out.println("Please Enter Country Zone Id :- ");
		String zoneId = ss.next();
		
		Que6_PrintDateByZoneId displayDate = new Que6_PrintDateByZoneId();
		
		displayDate.printDateByZone(zoneId);
		
		ss.close();
		
		

	}

}
