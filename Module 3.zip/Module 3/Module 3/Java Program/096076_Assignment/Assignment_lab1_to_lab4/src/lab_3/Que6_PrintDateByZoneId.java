package lab_3;

import java.time.ZoneId;
import java.time.ZonedDateTime;

public class Que6_PrintDateByZoneId {
	
	/**
	 * This Method Is Used To Display Date By Given ZoneId.
	 * 
	 * @param zoneId
	 */
	public void printDateByZone(String zoneId) {
		ZonedDateTime dateByZoneId = ZonedDateTime.now(ZoneId.of(zoneId));
		System.out.println("Current Time Is For Given Zone Is : -" + dateByZoneId);
	}

}
