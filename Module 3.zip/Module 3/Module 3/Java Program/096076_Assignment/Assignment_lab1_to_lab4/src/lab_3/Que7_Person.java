package lab_3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

/**
 * @author pmandawa
 *
 */

public class Que7_Person {

	private String firstName;
	private String lastName;
	private String gender;
	private String age;
	private String fullName;

	/**
	 * 
	 */
	public Que7_Person() {
		super();
	}

	/**
	 * @param firstName
	 * @param lastName
	 * @param gender
	 */
	public Que7_Person(String firstName, String lastName, String gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}

	/**
	 * This Method is used To Calculate Age.
	 * 
	 * @param dob
	 */
	public void calculateAge(String dob) {

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate oldDate = LocalDate.parse(dob, formatter);
		LocalDate currentDate = LocalDate.now();

		Period period = oldDate.until(currentDate);
		if ((period.get(ChronoUnit.DAYS) > 0)
				&& (period.get(ChronoUnit.MONTHS) > 0)
				&& (period.get(ChronoUnit.YEARS) > 0)) {

			String age =  period.get(ChronoUnit.YEARS) + " Years " + period.get(ChronoUnit.MONTHS) + " Months " + period.get(ChronoUnit.DAYS) + " Days ";
			this.setAge(age);

		} else {
			System.out
					.println("Your First Date Of Birth Is Not Correct...");
		}

	}
	
	/**
	 * This Method is Used To Set Full Name.
	 * 
	 */
	public void setFullName() {
		String fullName = this.getFirstName() + " " + this.getLastName();
		this.setFullName(fullName);
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return the age
	 */
	public String getAge() {
		return age;
	}

	/**
	 * @param age the age to set
	 */
	public void setAge(String age) {
		this.age = age;
	}

	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}

	/**
	 * @param fullName the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
	

}
