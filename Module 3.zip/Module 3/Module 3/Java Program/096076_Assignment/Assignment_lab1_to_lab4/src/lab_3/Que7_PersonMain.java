/**
 * 
 */
package lab_3;

import java.util.Scanner;

/**
 * @author pmandawa
 *
 */
public class Que7_PersonMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		
		System.out.println("Enter Your First Name :- ");
		String firstName = ss.next();
		
		System.out.println("Enter Your Last Name : - ");
		String secondName = ss.next();
		
		System.out.println("Enter Your Gender : 'M' or 'F' :- ");
		String gender = ss.next();
		
		System.out.println("Please Enter Your Date Of Birth"
				+ " In Formate 'dd/mm/yyyy'");
		String dob = ss.next();
		
		Que7_Person person = new Que7_Person(firstName, secondName, gender);
		person.calculateAge(dob);
		person.setFullName();
		// Now Print All The Details...

		System.out.println("Person Details");
		System.out.println("...........................");
		System.out.println("Full Name : " + person.getFullName());
		System.out.println("Gender : " + person.getGender());
		System.out.println("Age : " + person.getAge());
		
		ss.close();
		
	}

}
