package lab_4;

public class Que1_Account extends Que1_Person {

	private long accNum;
	private double balance;
	private Que1_Person accHolder;

	public Que1_Account() {
		this.balance = 500;
	}

	public void displayDetails() {
		System.out.println("Name : " + this.getAccHolder().getName());
		System.out.println("Age : " + this.getAccHolder().getAge());
		System.out.println("Account Number : " + this.getAccNum());
		System.out.println("Current Balance :" + this.getBalance());
		System.out.println("################################");
	}

	/**
	 * This Method Is Used To Generate Account Number.
	 * 
	 * @return AccNum
	 */
	public long generateAccNum() {

		long accNum = (long) (Math.random() * 10000);
		return accNum;
	}

	/**
	 * This Method is Used To Deposite Money In Bank Account.
	 * 
	 * @param amount
	 */
	public void deposite(double amount) {
		this.balance = this.balance + amount;
	}

	/**
	 * This Method is used To Withdraw Amount From Bank Account.
	 * 
	 * @param amount
	 */
	public boolean withDraw(double amount) {
		if ((amount > this.balance) && (this.balance <= 500)) {
			return false;
		} else {
			this.balance = this.balance - amount;
			return true;
		}
	}

	/**
	 * This Method Is Used To Return The Current balance.
	 * 
	 * @return balance
	 */
	public double getBalance() {
		return balance;
	}

	/**
	 * @return the accNum
	 */
	public long getAccNum() {
		return accNum;
	}

	/**
	 * @param accNum
	 *            the accNum to set
	 */
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	/**
	 * @return the accHolder
	 */
	public Que1_Person getAccHolder() {
		return accHolder;
	}

	/**
	 * @param accHolder
	 *            the accHolder to set
	 */
	public void setAccHolder(Que1_Person accHolder) {
		this.accHolder = accHolder;
	}

	/**
	 * @param balance
	 *            the balance to set
	 */
	public void setBalance(double balance) {
		this.balance = balance;
	}

}
