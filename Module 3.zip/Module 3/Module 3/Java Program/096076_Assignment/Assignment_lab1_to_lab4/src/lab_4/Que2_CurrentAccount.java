package lab_4;

public class Que2_CurrentAccount extends Que2_Account {

	private double overDraftLimit = 20000d;
	
	@Override
	public boolean withDraw(double amount) {
		double balance = super.getBalance();
		System.out.println(balance);
		if (amount <= overDraftLimit) {
			
			if ((amount > balance) && (balance <= 500)) {
				return false;
			} else {
				balance = balance - amount;
				return true;
			}
		}
		else{
			return false;
		}
	}
}
