package lab_4;

import java.util.Scanner;

public class Que2_MainClass {

	public static void main(String[] args) {
		
		Scanner ss = new Scanner(System.in);
		String choice = "Y";
		while(choice.equalsIgnoreCase("Y")) {
			
			
			System.out.println("Please select Your AccountType :");
			System.out.println("Saving");
			System.out.println("Current");
			String accountType = ss.next();
			
			if (accountType.equalsIgnoreCase("Saving")) {
				Que2_SavingAccount saving = new Que2_SavingAccount();
				Que2_Person person = new Que2_Person();
				
				System.out.println("Enter User Name :");
				String name = ss.next();
				
				System.out.println("Enter Age :");
				float age = ss.nextFloat();
				
				person.setName(name);
				person.setAge(age);
				long accNum = saving.generateAccNum();
				saving.setAccNum(accNum);
				saving.setAccHolder(person);
				String choice2 = "Y";
				while (choice2.equalsIgnoreCase("Y")) {
					System.out.println("Select Your Option :-");
					System.out.println("Deposite");
					System.out.println("Withdraw");
					System.out.println("Display");
					choice2 = ss.next();
					
					if (choice2.equalsIgnoreCase("Deposite")) {
						System.out.println("Please Enter Amount :");
						double amount = ss.nextDouble();
						saving.deposite(amount);
						saving.displayDetails();
					}
					
					if (choice2.equalsIgnoreCase("withdraw")) {
						System.out.println("Please Enter Amount :");
						double amount = ss.nextDouble();
						boolean isWithdraw = saving.withDraw(amount);
						if (isWithdraw) {
							saving.displayDetails();
						}
						else {
							System.out.println("Your Balance Is Low " + saving.getBalance());
						}
						
					}
					
					if (choice2.equalsIgnoreCase("Display")) {
						saving.displayDetails();
					}
					System.out.println("Do You Want Proceed Transaction. Press 'Y' To Continue and 'N' To Move On Previous Menu And Press 'Exit' To Exit Anytime");
					choice2 = ss.next();
					if (choice2.equalsIgnoreCase("Exit")) {
						System.exit(0);
						
					}
				}
				
				
				
				
				
			}
			
			if (accountType.equalsIgnoreCase("Current")) {
				
				
				Que2_CurrentAccount current = new Que2_CurrentAccount();
				Que2_Person person = new Que2_Person();
				
				System.out.println("Enter User Name :");
				String name = ss.next();
				
				System.out.println("Enter Age :");
				float age = ss.nextFloat();
				
				person.setName(name);
				person.setAge(age);
				long accNum = current.generateAccNum();
				current.setAccNum(accNum);
				current.setAccHolder(person);
				String choice2 = "Y";
				while (choice2.equalsIgnoreCase("Y")) {
					System.out.println("Select Your Option :-");
					System.out.println("Deposite");
					System.out.println("Withdraw");
					System.out.println("Display");
					choice2 = ss.next();
					
					if (choice2.equalsIgnoreCase("Deposite")) {
						System.out.println("Please Enter Amount :");
						double amount = ss.nextDouble();
						current.deposite(amount);
						current.displayDetails();
						
					}
					
					if (choice2.equalsIgnoreCase("withdraw")) {
						System.out.println("Please Enter Amount :");
						double amount = ss.nextDouble();
						boolean isWithdraw = current.withDraw(amount);
						if (isWithdraw) {
							current.displayDetails();
						}
						else {
							System.out.println("Your Balance Is Low " + current.getBalance());
						}
						
					}
					
					if (choice2.equalsIgnoreCase("Display")) {
						current.displayDetails();
					}
					System.out.println("Do You Want Proceed Transaction. Press 'Y' To Continue and 'N' To Move On Previous Menu And Press 'Exit' To Exit Anytime");
					choice2 = ss.next();
					if (choice2.equalsIgnoreCase("Exit")) {
						System.exit(0);
						
					}
				}
				
				
				
				
			}
			
			System.out.println("Do You Want To Continue Press 'Y' To Continue Press 'N' To Exit :-");
			choice = ss.next();
			if (choice.equalsIgnoreCase("N")) {
				System.exit(0);
			}
			
		}
		
		

		ss.close();
		
		

	}

}
