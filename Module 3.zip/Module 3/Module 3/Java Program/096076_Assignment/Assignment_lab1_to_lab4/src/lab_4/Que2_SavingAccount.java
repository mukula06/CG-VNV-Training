package lab_4;

public class Que2_SavingAccount extends Que2_Account {
	
	final float minBal = 500;
	
	@Override
	public boolean withDraw(double amount) {
		double balance = super.getBalance();
		if ( (amount > balance) || (balance <= 500) || (balance < minBal) ) {
			return false;
		} else {
			balance = balance - amount;
			super.setBalance(balance);
			return true;
		}
	}
	
	
	


}
