package com.cg.els.main;

import java.util.Scanner;

import com.cg.els.bean.Employee;
import com.cg.els.service.EmployeeService;
import com.cg.els.service.impl.EmployeeServiceImpl;

/**
 * 
 * @author pmandawa
 *
 */
public class EmployeeMain {

	/**
	 * 
	 * @param args
	 */
	static int index = 0;
	public static void main(String[] args) {
		String choice = "Y";
		Scanner ss = new Scanner(System.in);
		System.out
				.println("#################### Welcome To Insurance System ####################");
		System.out.println("");
		System.out.println("Enter Maximum No Of Employee You Want ...");
		int maxEmp = ss.nextInt();

		Employee[] employee = new Employee[maxEmp];
		EmployeeService empService = new EmployeeServiceImpl();
		
		while (choice.equalsIgnoreCase("Y")) {

			System.out
					.println("Please Select The Operation You Want To Do :- ");
			System.out.println("Type 'Add' To Add User : ");
			System.out.println("Type 'Find' To Find Insurance Scheme Of Particular User.");
			System.out
					.println("Type 'Display' To Display All Details Of Employee ");

			String optChoice = ss.next();

			switch (optChoice.toLowerCase()) {

			case "add":
				String addEmp = "Y";
				
				while (addEmp.equalsIgnoreCase("Y")) {
					if (index > maxEmp - 1) {
						System.out
								.println("Maximum Employee Limit Is Reached...");
						break;
					} else {
						try {
							employee[index] = empService.addDetails(ss);
						} catch (Exception e) {
							System.out.println(e.getMessage());
							break;
						}
						System.out
								.println("You Want To Add More User Press 'Y' To Continue And 'N' To Move Out From This...");
						addEmp = ss.next();
					}
					index++;
				}
				break;

			case "display":
				empService.display(employee);
				break;

			case "find":
				System.out.println("Please Enter Employee Id : ");
				long empId = ss.nextLong();
				empService.getDetails(empId, employee);
				break;

			default:
				System.out.println("You Have Entered Wrong Operation ");

			}

			System.out
					.println("Do You Want To Continue ... Press 'Y' To Continue And 'N' To Exit.");
			choice = ss.next();

		}

		ss.close();

	}

}
