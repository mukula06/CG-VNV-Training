package com.cg.els.service;

import java.util.Scanner;

import com.cg.els.bean.Employee;

/**
 * 
 * @author pmandawa
 *
 */
public interface EmployeeService {

	/**
	 * 
	 * @param id
	 * @param employee
	 * @return
	 */
	public Employee getDetails(long id, Employee[] employee);

	/**
	 * 
	 * @param employee
	 * @return Employee
	 * @throws Exception 
	 */
	public Employee addDetails(Scanner scanner) throws Exception;

	/**
	 * 
	 * @param salary
	 * @param designation
	 * @return String
	 */
	public String getInsuranceScheme(double salary, String designation);

	/**
	 * @param employee
	 * @return void
	 */
	public void display(Employee[] employee);

}
