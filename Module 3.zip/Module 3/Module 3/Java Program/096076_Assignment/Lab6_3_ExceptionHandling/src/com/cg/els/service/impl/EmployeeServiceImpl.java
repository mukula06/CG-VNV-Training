package com.cg.els.service.impl;

import java.util.Map;
import java.util.Scanner;

import com.cg.els.bean.Employee;
import com.cg.els.exception.EmployeeException;
import com.cg.els.service.EmployeeService;

/**
 * 
 * This Is The Implimentation Class Of EmployeeService.
 * 
 * @author pmandawa
 *
 */
public class EmployeeServiceImpl implements EmployeeService{

	@Override
	public String getInsuranceScheme(double salary, String designation) {
		
		if ( (( salary > 5000 ) && ( salary < 20000 ))  &&  designation.equalsIgnoreCase("System Associate") ) {
			return "Scheme C";
		}
		
		else if ( (( salary >= 20000 ) && ( salary < 40000 ))  &&  designation.equalsIgnoreCase("Programmer") ) {
			return "Scheme B";
		}
		
		else if ( (( salary >= 40000 ))  &&  designation.equalsIgnoreCase("Manager") ) {
			return "Scheme A";
		}
		
		else if ( (( salary < 5000 ))  &&  designation.equalsIgnoreCase("Clerk") ) {
			return "No Scheme";
		}
		
		else {
			return "You Have Entered Wrong Details";
		}
		
	}

	@Override
	public Employee addDetails(Scanner scanner) throws Exception {
		
		Employee emp = new Employee();
		System.out.println("Enter User Id :");
		long id = scanner.nextLong();
		emp.setId(id);
		
		System.out.println("Enter User Name");
		String name = scanner.next();
		emp.setName(name);
		
		System.out.println("Enter User Salary");
		double salary = scanner.nextDouble();
		try {
			checkSalary(salary);
			emp.setSalary(salary);
		} catch (EmployeeException e) {
			throw new Exception(e.getMessage());
		}
		
		
		System.out.println("Enter User Designation");
		String designation = scanner.next();
		emp.setDesignation(designation);
		
		String insuranceScheme = this.getInsuranceScheme(salary, designation);
		emp.setInsuranceScheme(insuranceScheme);
		return emp;
	}

	@Override
	public Employee getDetails(long id, Employee[] employee) {
		System.out.println("####################");
		for (Employee emp : employee) {
			if (emp != null) {
				if (id == emp.getId()) {
					
					System.out.println("Employee Id : " +emp.getId());	
					System.out.println("Employee Name : " +emp.getName());	
					System.out.println("Employee Salary : " +emp.getSalary());	
					System.out.println("Employee Designation : " +emp.getDesignation());
					System.out.println("Employee Insurance Scheme : " +emp.getInsuranceScheme());	
					System.out.println("####################");
				}
				
			}
					
		}
		return null;
	}

	@Override
	public void display(Employee[] employee) {
		System.out.println("####################");
		for (Employee emp : employee) {
			if (emp != null) {
				System.out.println("Employee Id : " +emp.getId());	
				System.out.println("Employee Name : " +emp.getName());	
				System.out.println("Employee Salary : " +emp.getSalary());	
				System.out.println("Employee Designation : " +emp.getDesignation());
				System.out.println("Employee Insurance Scheme : " +emp.getInsuranceScheme());	
				System.out.println("####################");
			}
					
		}
		
	}

	
	public static void checkSalary(double salary) throws EmployeeException {
		if (salary < 3000) {
			throw new EmployeeException("Salary Less Then 3000");
		}
	}
	

}
