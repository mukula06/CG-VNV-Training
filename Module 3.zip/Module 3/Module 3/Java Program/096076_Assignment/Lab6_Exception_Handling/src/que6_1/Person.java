package que6_1;

/**
 * @author pmandawa
 *
 */

public class Person {

	private String firstName;
	private String lastName;
	private char gender;

	/**
	 * 
	 */
	public Person() {
		super();
	}

	/**
	 * @param firstName
	 * @param lastName
	 * @param gender
	 */
	public Person(String firstName, String lastName, char gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		
	}
	
	/**
	 * 
	 * @param firstName
	 * @param lastName
	 * @throws PersonException
	 */
	public static void validateName(String firstName, String lastName)
			throws PersonException {
		if ((firstName == null && lastName == null)
				|| (firstName.length() == 0 && lastName.length() == 0)) {
			throw new PersonException("First Name And Last Name Is Blank...");
		}

		if ((firstName == null && lastName != null)
				|| (firstName.length() == 0 && lastName.length() != 0)){
			throw new PersonException("First Name Is Blank...");
		}

		if ((firstName != null && lastName == null)
				|| (firstName.length() != 0 && lastName.length() == 0)){
			throw new PersonException("Last Name Is Blank...");
		}
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the gender
	 */
	public char getGender() {
		return gender;
	}

	/**
	 * @param gender
	 *            the gender to set
	 */
	public void setGender(char gender) {
		this.gender = gender;
	}

}
