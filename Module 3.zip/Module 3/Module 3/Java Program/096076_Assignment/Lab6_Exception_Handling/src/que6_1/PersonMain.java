/**
 * 
 */
package que6_1;

import java.util.Scanner;

/**
 * @author pmandawa
 *
 */
public class PersonMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		String choice = "y";
		while(choice.equalsIgnoreCase("Y")) {
			
		Scanner ss = new Scanner(System.in);
		
		Person person = new Person();
		
		System.out.println("Enter First Name : ");
		String firstName = ss.nextLine();
		
		System.out.println("Enter Second Name : ");
		String lastName = ss.nextLine();
		
		System.out.println("Enter Gender : ");
		String gender = ss.next();
		
		try {
			Person.validateName(firstName, lastName);
			person.setFirstName(firstName);
			person.setLastName(lastName);
			person.setGender(gender.charAt(0));
			
			System.out.println("Person Details");
			System.out.println("...........................");
			System.out.println("First Name : " + person.getFirstName());
			System.out.println("Last Name : " + person.getLastName());
			System.out.println("Gender : " + person.getGender());
			
		} catch (PersonException e) {
			System.out.println(e.getMessage());
		}
		
		System.out.println("Press 'y' To Continue And other Key To Exit");
		choice = ss.next();
		}
		
	}

}
