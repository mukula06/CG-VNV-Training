package que6_2;

public class PersonException extends Exception{
	
	public PersonException() {
		super();
	}
	
	public PersonException(String message) {
		super(message);
	}


}
