package que6_2;

public class SavingAccount extends Account {
	
	final float minBal = 500;
	
	@Override
	public boolean withDraw(double amount) {
		double balance = super.getBalance();
		if ( (amount > balance) || (balance <= 500) || (balance < minBal) ) {
			return false;
		} else {
			balance = balance - amount;
			super.setBalance(balance);
			return true;
		}
	}
	
	
	


}
