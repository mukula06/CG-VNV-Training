package com.cg.mobileapp.dao;

import java.util.List;

import com.cg.mobileapp.dto.Mobiles;
import com.cg.mobileapp.dto.PurchaseDetails;
import com.cg.mobileapp.exception.MobileException;

public interface MobileAppDao {
	
	public boolean isEmptyRecord();

	public void addCustomerDetails(PurchaseDetails purchaseDetails) throws MobileException;
		
	public List<Mobiles> showAll() throws MobileException;
	
	public List<Mobiles> searchByRange(int min, int max) throws MobileException;
	
	public List<PurchaseDetails> showAllPurchase() throws MobileException;
	
	public PurchaseDetails showPurchaseById(PurchaseDetails purchase) throws MobileException;
}
