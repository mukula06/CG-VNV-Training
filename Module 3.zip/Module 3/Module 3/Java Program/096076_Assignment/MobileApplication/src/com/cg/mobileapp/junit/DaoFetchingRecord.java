package com.cg.mobileapp.junit;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobileapp.util.DbUtil;


public class DaoFetchingRecord {
	
	Connection con = null;
	Statement pst = null;
	ResultSet rs = null;
	
	@Before
	public void doBefore() throws SQLException  {
		con = DbUtil.getConnection();
		String query = "SELECT * from mobiles";
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(query);
	}
	
	@Test
	public void doTest() throws SQLException {
		assertEquals(true,rs.next());
	}

	@After
	public void doAfter() throws SQLException {
		con.close();
	}

}
