package com.cg.mobileapp.junit;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobileapp.util.DbUtil;



public class DaoInsertingTesting {

	Connection con = null;
	PreparedStatement pst = null;
	
	@Before
	public void before() throws SQLException  {
		con = DbUtil.getConnection();
		String query = "Insert into purchaseDetails values(?,?,?,?,sysdate,?)";
		pst.setInt(1, 1);
		pst.setString(2, "Prathu");
		pst.setString(3, "Prathu@gmail.com");
		pst.setLong(4, 941387731);
		pst.setLong(5, 1001);
		
		
	}
	
	
	@Test
	public void test() throws SQLException {
		assertEquals(1, pst.executeUpdate());
	}
	
	@After
	public void after() throws SQLException {
		con.close();
	}

}
