package com.cg.mobileapp.service;

import java.awt.Dialog.ModalExclusionType;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.mobileapp.dao.MobileAppDao;
import com.cg.mobileapp.dao.MobileAppDaoImpl;
import com.cg.mobileapp.dto.Mobiles;
import com.cg.mobileapp.dto.PurchaseDetails;
import com.cg.mobileapp.exception.MobileException;

public class MobileAppServiceImpl implements MobileAppService {

	MobileAppDao mobDao = new MobileAppDaoImpl();
	
	
	@Override
	public void addCustomerDetails(PurchaseDetails pur) throws MobileException  {
		mobDao.addCustomerDetails(pur);
	}

	@Override
	public boolean nameValidation(String name) throws MobileException {
		String pattern = "[A-Z][a-z]{2,19}";
		//String pattern = "^$";
		
		boolean isValid =  Pattern.matches(pattern, name);
		if (isValid) {
			return true;
		} else {
			throw new MobileException("First Letter Should Be Capital And Length 3 to 20");
		}
		
		
	}

	@Override
	public boolean mailIdValidation(String mailId) throws MobileException {
		
		if (mailId.contains("@") && mailId.contains(".com")) {
			return true;
		} else {
			throw new MobileException("Invalid Mail Id");
		}
		
		
		
	}

	@Override
	public boolean phoneNoValidation(long phnNo) throws MobileException {
		String phone = String.valueOf(phnNo);
		
		if ( phone.length() == 10) {
			return true;
		} else {
			throw new MobileException("Invalid Phone Number Length Must Be 10");
		}
	}

	@Override
	public List<Mobiles> showAll() throws MobileException {
		List<Mobiles> myList = mobDao.showAll();
		return myList;
	}

	@Override
	public  List<Mobiles> searchByRange(int min, int max) throws MobileException {
		 List<Mobiles> mobilesByRange = mobDao.searchByRange(min, max);
		return mobilesByRange;
	}

	@Override
	public List<PurchaseDetails> showAllPurchase() throws MobileException {
		List<PurchaseDetails> list = mobDao.showAllPurchase();
		return list;
	}

	@Override
	public PurchaseDetails showPurchaseById(PurchaseDetails purchase)
			throws MobileException {
		// TODO Auto-generated method stub
		return null;
	}

	

	
}
