package com.cg.mobileapp.ui;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

import com.cg.mobileapp.dto.Mobiles;
import com.cg.mobileapp.dto.PurchaseDetails;
import com.cg.mobileapp.exception.MobileException;
import com.cg.mobileapp.service.MobileAppService;
import com.cg.mobileapp.service.MobileAppServiceImpl;

public class MainClass {

	public static void main(String[] args) {
		
		MobileAppService mobService = new MobileAppServiceImpl();
		
		Scanner ss = new Scanner(System.in);
		
		String choice = "Y";
		
		while (choice.equalsIgnoreCase("Y")) {
			chooseOption();
			String option = ss.next();
			
			switch (option) {
			
			case "add" :
				
				PurchaseDetails pur = new PurchaseDetails();
				
				System.out.println("Enter Customer Name :");
				String name = ss.next();
				boolean isValidName;
				try {
					
					isValidName = mobService.nameValidation(name);
					
					if (isValidName) {
						
						System.out.println("Enter Customer MailId");
						String mail = ss.next();
						boolean isValidMail = mobService.mailIdValidation(mail);
						
						if (isValidMail) {
							System.out.println("Enter Customer Phone No :");
							long phnNo = ss.nextLong();
							boolean isValidPhone = mobService.phoneNoValidation(phnNo);
							
							if (isValidPhone) {
								
								System.out.println("Enter Mobile Id:");
								long mobileId = ss.nextLong();
								
								pur.setCname(name);
								pur.setMailId(mail);
								pur.setMobileId(mobileId);
								pur.setPhoneNo(phnNo);
								
								
								
								mobService.addCustomerDetails(pur);
								
							}
							
							
						}
						
						
					}
					
				} catch (MobileException e) {
					System.out.println(e.getMessage());
				}
				
				break;
				
			
				
			case "showall" :
				List<Mobiles> myList = null;
				try {
					myList = mobService.showAll();
					displayList(myList);
				} catch (MobileException e) {
					System.out.println(e.getMessage());
				}
				
				break;
				
			case "search" :
				System.out.println("Enter Minimum Range");
				int min = ss.nextInt();
				
				System.out.println("Enter Maximum Range");
				int max = ss.nextInt();
				List<Mobiles> mobile = null;
				try {
					 mobile = mobService.searchByRange(min, max);
					 displayList(mobile);
				} catch (MobileException e) {
					System.out.println(e.getMessage());
				}
				
				break;
				
				
			case "displayall":
			
				try {
					List<PurchaseDetails> listPurchase = mobService.showAllPurchase();
					displayListOfPurchase(listPurchase);
					break;
				} catch (MobileException e) {
					System.out.println("Error");
				}
				
			case "display":
				
				break;
				
				}
			
			}
			
		}
	
	public static void displayMobileById(Mobiles mobile) {
		
		
			System.out.println("");
			System.out.println("##############");
			System.out.println("Mobile Id :" + mobile.getMobileId());
			System.out.println("Mobile Name :" + mobile.getName());
			System.out.println("Mobile Price :" + mobile.getPrice());
			System.out.println("Mobile Quantity :" + mobile.getQuantity());
			System.out.println("##############");
			System.out.println("");
			
		
		
	}
	

	public static void displayList(List<Mobiles> myList) {
		
		System.out.println("Details Are ...");
		
		
		for(Mobiles mobile : myList) {
			System.out.println("");
			System.out.println("##############");
			System.out.println("Mobile Id :" + mobile.getMobileId());
			System.out.println("Mobile Name :" + mobile.getName());
			System.out.println("Mobile Price :" + mobile.getPrice());
			System.out.println("Mobile Quantity :" + mobile.getQuantity());
			System.out.println("##############");
			System.out.println("");
			
		}
		
	}
	
	
	public static void displayPurchase(PurchaseDetails purchase) {
		
		System.out.println("Details Are ...");
			System.out.println("");
			System.out.println("##############");
			System.out.println("Purchase Id : " + purchase.getPurchaseId());
			System.out.println("Customer Name : " + purchase.getCname());
			System.out.println("Customer Mail Id : " + purchase.getMailId());
			System.out.println("customer Phone No : " + purchase.getPhoneNo());
			System.out.println("Purchase Date : " + purchase.getPurchaseDate());
			System.out.println("Mobile : " + purchase.getMobileId());
			System.out.println("##############");
			System.out.println("");
	}
	
	
	public static void displayListOfPurchase(List<PurchaseDetails> myList) {
		
		System.out.println("Details Are ...");
		
		for(PurchaseDetails purchase : myList) {
			System.out.println("");
			System.out.println("##############");
			System.out.println("Purchase Id : " + purchase.getPurchaseId());
			System.out.println("Customer Name : " + purchase.getCname());
			System.out.println("Customer Mail Id : " + purchase.getMailId());
			System.out.println("customer Phone No : " + purchase.getPhoneNo());
			System.out.println("Purchase Date : " + purchase.getPurchaseDate());
			System.out.println("Mobile : " + purchase.getMobileId());
			System.out.println("##############");
			System.out.println("");
			
		}
		
	}
	
	
	public static void chooseOption() {
		System.out.println("Please Select Your Option");
		System.out.println("Press 'Add' To Add Purchase");
		System.out.println("Press 'showall' To View All Details Of Mobiles");
		System.out.println("Press 'search' To Search For a Given Range");
		System.out.println("Press 'display' To Display Purchase Details By Id");
		System.out.println("Press 'displayall' To Display All Purchase Details");
	}

}
