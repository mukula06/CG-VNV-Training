package com.cg.mobileapp.util;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;





import org.apache.log4j.Logger;

public class DbUtil {
	
	static Connection con = null;
	//private static final Logger myLog = Logger.getLogger(DbUtil.class);
	
	public static Connection getConnection() {
		
		try {
			
			FileInputStream fileRead = new FileInputStream("oracleConfig.properties");
			Properties properties = new Properties();
			properties.load(fileRead);
			//String driver = properties.getProperty("oracle.driver");
			
			String url = properties.getProperty("oracle.url");
			String username = properties.getProperty("oracle.username");
			String password = properties.getProperty("oracle.password");
			
			//Class.forName(driver);
			
			con = DriverManager.getConnection(url, username, password);
			
			//myLog.info("Logger : Connection Done... [DbUtil] ");
			System.out.println("Connection Done...");
		
			
		} catch (Exception e) {
			e.printStackTrace();
			//myLog.info("Logger : Error In Connecting [DbUtil] " + e.getMessage(), e);
		}
		
		return con;
		
	}


}
