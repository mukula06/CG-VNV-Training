package com.cg.mobileapp.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.mobileapp.dto.Mobiles;
import com.cg.mobileapp.dto.PurchaseDetails;
import com.cg.mobileapp.exception.MobileException;
import com.cg.mobileapp.util.DbUtil;

public class MobileAppDaoImpl implements MobileAppDao {
	
	static List<Mobiles> myList = new ArrayList<Mobiles>();
	
	static List<PurchaseDetails> myList2 = new ArrayList<PurchaseDetails>();
	
	private static final Logger myLogger = Logger.getLogger(MobileAppDaoImpl.class);

	@Override
	public void addCustomerDetails(PurchaseDetails purchaseDetails) throws MobileException {
		
		boolean isEmpty = this.isEmptyRecord();
		Connection con = null;
		
		if (!isEmpty) {
			
			try {
				
				con = DbUtil.getConnection();
				String query = "Insert into purchaseDetails values(?,?,?,?,sysdate,?)";
				PreparedStatement st = con.prepareStatement(query);
				int id = this.getSeq();
				boolean check = this.isValid(purchaseDetails.getMobileId());
				if (check) {
					st.setInt(1, id);
					st.setString(2, purchaseDetails.getCname());
					st.setString(3, purchaseDetails.getMailId());
					st.setLong(4, purchaseDetails.getPhoneNo());
					st.setLong(5, purchaseDetails.getMobileId());
					
					int checked = st.executeUpdate();
					
					if (checked == 1) {
						
						this.updatePurchaseDetails(purchaseDetails);
						myLogger.info("Logger : Query Executed ...");
						System.out.println("Done");
					}
					
				}
				else {
					System.out.println("Please Enter Correct Mobile Id");
					myLogger.info("Logger : Please Enter Correct Mobile Id");
				}
				
				
				
				
			} catch (SQLException e) {
				System.out.println("Error");
				myLogger.info("Logger : Error");
				
			}
			
		}
		
	}
	

	@Override
	public boolean isEmptyRecord() {
		
		
		String query = "SELECT * from mobiles";
		Connection con = null;
		int counter = 0;
		
		try {
			con = DbUtil.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			while (rs.next()) {
				counter++;
			}
			
			if (counter == 0) {
				return true;
			}
			myLogger.info("Logger : Connection Done");
			
		} catch (Exception e) {
			myLogger.info("Logger : Error In Connection ...");
			System.out.println("Error In Connection");
			
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				myLogger.info("Logger : Error In Closing...");
				System.out.println("Error In Closing Connection");
			}
		}
		
		return false;
	}
	
	
	public String searchMobileRecord(long id) {
		String query = "SELECT quantity from mobiles where mobileId = ?";
		Connection con = null;
		
		try {
			con = DbUtil.getConnection();
		
			PreparedStatement st = con.prepareStatement(query);
			st.setLong(1, id);
			ResultSet rs = st.executeQuery();
			
			while (rs.next()) {
				myLogger.info("Logger : Search Done");
				return rs.getString("quantity");
			}
			
			
			
		} catch (Exception e) {
			myLogger.info("Logger : Error In Connection ...");
			System.out.println("Error In Connection");
			
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				myLogger.info("Logger : Error In Closing...");
				System.out.println("Error In Closing Connection");
			}
		}
		
		return null;
	}
	
	public void updatePurchaseDetails(PurchaseDetails purchase) throws MobileException {
		
		
		Connection con = null;
		
		String quant = this.searchMobileRecord(purchase.getMobileId());
		String quantity = String.valueOf(Double.parseDouble(quant) - 1);
		
		String query = "update mobiles set quantity = ? where mobileId = ?";
		
		try {
			con = DbUtil.getConnection();
			PreparedStatement st = con.prepareStatement(query);
			st.setString(1, quantity);
			st.setLong(2, purchase.getMobileId());
			
			int result = st.executeUpdate();
			
			if (result > 0) {
				myLogger.info("Logger : Updated");
				System.out.println("Updated");
			} else {
				myLogger.info("Logger : Error In Connection ...");
				throw new MobileException("Not Able To Update");
			}
			
			
			myLogger.info("Logger : Updation Done");
			
		} catch (Exception e) {
			//myLogger.info("Logger : Error In Connection [Generate Sequence No.] ...");
			System.out.println("Error In Connection");
			myLogger.info("Logger : Error In Connection ...");
			throw new MobileException("Error In Connection");
			
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				//myLogger.info("Logger : Error In Closing [Generate Sequence No.] ...");
				System.out.println("Error In Closing Connection");
				myLogger.info("Logger : Error In Closing ...");
				throw new MobileException("Error In Closing");
			}
		}
		
		
	}
	
	
	
	
	public boolean isValid(long id) {
		
		int mobId = 0;
		String query = "SELECT mobileid from mobiles";
		Connection con = null;
		
		try {
			con = DbUtil.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			while (rs.next()) {
				if (id == Integer.parseInt(rs.getString("mobileId"))) {
					return true;
					
				}
			}
			
			
		} catch (Exception e) {
			myLogger.info("Logger : Error In Connection");
			System.out.println("Error In Connection");
			
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				myLogger.info("Logger : Error In Closing");
				System.out.println("Error In Closing Connection");
			}
		}
		
		return false;
		
	}
	
	
	public  int getSeq() {
		
		int mobId = 0;
		String query = "SELECT mobId_seq.NEXTVAL FROM DUAL";
		Connection con = null;
		
		try {
			con = DbUtil.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			while (rs.next()) {
				mobId = rs.getInt(1);
			}
		
			
		} catch (Exception e) {
			myLogger.info("Logger : Error In Connection");
			System.out.println("Error In Connection");
			
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				myLogger.info("Logger : Error In Closing");
				System.out.println("Error In Closing Connection");
			}
		}
		
		
		return mobId;
	}


	@Override
	public List<Mobiles> showAll() throws MobileException {
		
		String query = "SELECT * from mobiles";
		Connection con = null;
		
		try {
			con = DbUtil.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			while (rs.next()) {
				Mobiles mobile = new Mobiles();
				
				mobile.setMobileId(Integer.parseInt(rs.getString("mobileId")));
				mobile.setName(rs.getString("name"));
				mobile.setPrice(Double.parseDouble(rs.getString("price")));
				mobile.setQuantity(rs.getString("Quantity"));
				
				myList.add(mobile);
				
			}
			myLogger.info("Logger : Fetching Done...");
			return myList;
			
			
		} catch (Exception e) {
			myLogger.info("Logger : Error In Connection");
			System.out.println("Error In Connection");
			
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				myLogger.info("Logger : Error In Closing");
				System.out.println("Error In Closing Connection");
			}
		}
		
		return null;
	}


	@Override
	public  List<Mobiles> searchByRange(int min, int max) throws MobileException {
		
		myList.clear();
		String query = "SELECT * from mobiles where price between "+min+" and "+max+"";
		Connection con = null;
		
		try {
			con = DbUtil.getConnection();
			PreparedStatement st = con.prepareStatement(query);
			
			ResultSet rs = st.executeQuery(query);
			
			while (rs.next()) {
				Mobiles mobile = new Mobiles();
				
				mobile.setMobileId(Integer.parseInt(rs.getString("mobileId")));
				mobile.setName(rs.getString("name"));
				mobile.setPrice(Double.parseDouble(rs.getString("price")));
				mobile.setQuantity(rs.getString("Quantity"));
				
				myList.add(mobile);
				
			}
			
			return myList;
			
			
		} catch (Exception e) {
			myLogger.info("Logger : Error In Connection");
			System.out.println("Error In Connection");
			e.printStackTrace();
			
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				myLogger.info("Logger : Error In Closing");
				System.out.println("Error In Closing Connection");
			}
		}
		
		return null;
	}


	@Override
	public List<PurchaseDetails> showAllPurchase() throws MobileException {
		String query = "SELECT * from purchasedetails";
		Connection con = null;
		
		try {
			con = DbUtil.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			while (rs.next()) {
				PurchaseDetails purchase = new PurchaseDetails();
				purchase.setMobileId(Integer.parseInt(rs.getString("mobileId")));
				purchase.setCname(rs.getString("cname"));
				purchase.setMailId(rs.getString("mailId"));
				purchase.setPhoneNo(Long.parseLong(rs.getString("phoneNo")));
				purchase.setPurchaseDate(rs.getDate("purchaseDate"));
				purchase.setPurchaseId(Long.parseLong(rs.getString("purchaseId")));
				
				myList2.add(purchase);
				
			}
			
			return myList2;
			
			
		} catch (Exception e) {
			myLogger.info("Logger : Error In Connection");
			System.out.println("Error In Connection");
			
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				myLogger.info("Logger : Error In Closing");
				System.out.println("Error In Closing Connection");
			}
		}
		
		return null;
	}


	@Override
	public PurchaseDetails showPurchaseById(PurchaseDetails purchase)
			throws MobileException {
		
		return null;
	}


}
