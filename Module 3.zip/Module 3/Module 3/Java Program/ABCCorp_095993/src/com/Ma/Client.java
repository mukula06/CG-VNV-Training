/**
 * 
 */
package com.Ma;

import java.util.Scanner;

import com.Ma.Cust.*;
import com.Ma.Exception.CustCEException;
import com.Ma.dao.*;
import com.Ma.valid.*;


/**
 * @author mukagraw
 * 
 */
public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Scanner scanner = new Scanner(System.in);
			int cnt = 1;
			int id;
			String name;
			String option = "Y";
			do {
				System.out.println("Please enter your choice: \n1:Add\n2:Exit");
				cnt = scanner.nextInt();

				String opt = "Y";
				Customer dummy = new Customer();
				switch (cnt) {
				case 1:
					do {
						System.out.println("Enter Customer Name:");
						String Nam = scanner.next();
						dummy.setCustomerName(Nam);

						System.out.println("Enter Account Type:");
						String Acc = scanner.next();
						Acc = Acc.toUpperCase();
						dummy.setAccountType(Acc.toUpperCase());

						System.out.println("Enter Mobile Number:");
						String Mno = scanner.next();
						dummy.setMobileNumber(Mno);
						
						String pat="[a-z][a-z][a-z].*";
						String pat2="prepaid|postpaid|POSTPAID|PREPAID";
						String pat3="[0-9]{10}";
						DataValidator dv=new DataValidator();
						//DBHelper db=new DBHelper();
						boolean ans1=dv.Datavalidate(pat, Nam);
						boolean ans2=dv.Datavalidate(pat2, Acc);
						boolean ans3=dv.Datavalidate(pat3, Mno);
						System.out.println("Name pattern is:"+ans1);
						System.out.println("Account pattern is:"+ans2);
						System.out.println("Mobile no pattern is:"+ans3);

						System.out.println("you entered:    " + Nam + " " + Acc
								+ " " + Mno);
						
						if(ans1==true)
						{
							if(ans2==true)
							{
								if(ans3==true)
								{
									DBHelper.addCustomer(dummy);
								}
							}
						}

						
						System.out
								.println("Do you want to add more employees?");
						opt = scanner.next();

					} while (opt.equals("Y") || opt.equals("y"));

					break;

				default: {
					System.out.println("Exiting..");
					System.exit(0);
				}

				}
				System.out.println("Do you want to continue? (y/n)");
				option = scanner.next();
				// cnt = scanner.nextInt();

			} while (option.equals("Y") || option.equals("y"));

			System.out.println("exiting...");

		}

		catch (CustCEException e) {

			System.out.println("Exception occured" + e);

		} catch (Exception e) {
			System.out.println("Something went wrong..exiting..");
		}

	}

}
