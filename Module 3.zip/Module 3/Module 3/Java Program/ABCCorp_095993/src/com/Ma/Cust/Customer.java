/**
 * 
 */
package com.Ma.Cust;

/**
 * @author mukagraw
 * 
 */
public class Customer {

	private long custId;
	private String customerName;
	private String accountType;
	private String mobileNumber;

	/**
	 * @param custId
	 * @param customerName
	 * @param accountType
	 * @param mobileNumber
	 */
	public Customer(long custId, String customerName, String accountType,
			String mobileNumber) {
		super();
		this.custId = custId;
		this.customerName = customerName;
		this.accountType = accountType;
		this.mobileNumber = mobileNumber;
	}

	/**
	 * 
	 */
	public Customer() {
		super();
	}

	/**
	 * @return the custId
	 */
	public long getCustId() {
		return custId;
	}

	/**
	 * @param custId
	 *            the custId to set
	 */
	public void setCustId(long custId) {
		this.custId = custId;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName
	 *            the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the accountType
	 */
	public String getAccountType() {
		return accountType;
	}

	/**
	 * @param accountT
	 *            the accountType to set
	 */
	public void setAccountType(String accountT) {
		this.accountType = accountT;
	}

	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @param mobileNumber
	 *            the mobileNumber to set
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

}
