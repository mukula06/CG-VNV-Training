/**
 * 
 */
package com.Ma.Exception;

import java.sql.SQLException;

/**
 * @author mukagraw
 * 
 */
public class CustCEException extends Exception {
	public CustCEException() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {

		return " CustCEException ,Database operation failed ";

	}

}
