/**
 * 
 */
package com.Ma.dao;

import java.sql.*;

import com.Ma.Cust.Customer;
import com.Ma.Exception.CustCEException;

/**
 * @author mukagraw
 * 
 */
public class DBHelper {

	public DBHelper() {
		super();
		// emplist =new ArrayList();
		// TODO Auto-generated constructor stub

	}

	public static int addCustomer(Customer e) throws Exception {
		Connection con = null;
		try {
			con = DBUtil.getInstance().getConnection();

			String Nam = e.getCustomerName();
			String Acc = e.getAccountType();
			String Mno = e.getMobileNumber();

			Statement st = con.createStatement();

			int row = st
					.executeUpdate("INSERT INTO Customer VALUES (seq_cust_id.NEXTVAL,'"
							+ Nam + "','" + Acc + "'," + Mno + ")");

			ResultSet Custo = st
					.executeQuery("Select * from Customer where customer_name = '"
							+ Nam + "'");
			Custo.next();
			System.out
					.println("Your details successfully recorded with Customer id "
							+ Custo.getLong(1));

			if (row != 1)
				throw new CustCEException();
			else
				System.out.println("Employee inserted");
			return row;
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			// e1.printStackTrace();
			throw new CustCEException();
		} finally {

			try {
				con.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				throw new CustCEException();
			}
		}

	}
}
