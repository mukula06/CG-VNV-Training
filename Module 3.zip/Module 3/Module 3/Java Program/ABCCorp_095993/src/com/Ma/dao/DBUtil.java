package com.Ma.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.Ma.Exception.CustCEException;

//import com.sj.exception.EmpCRUDException;

/**
 * 
 * @author mukagraw
 * 
 */
public class DBUtil {
	static DBUtil dbutil;
	static Connection conn;
	static Properties props;
	static String url, uid, pass;

	private DBUtil() throws CustCEException, Exception {
		try {
			props = new Properties();
			FileInputStream fis = null;
			fis = new FileInputStream("DataBa.properties");
			props.load(fis);

			Class.forName(props.getProperty("DB_DRIVER_CLASS"));

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new CustCEException();
		}
	}

	public static Connection getConnection() throws CustCEException, Exception {
		// TODO Auto-generated method stub

		try {
			url = props.getProperty("DB_URL");
			uid = props.getProperty("DB_USERNAME");
			pass = props.getProperty("DB_PASSWORD");
			return (DriverManager.getConnection(url, uid, pass));
			// Connection
			// con=DriverManager.getConnection("jdbc:oracle:thin:@10.125.6.62:1521:Orcl11g","Lab1105trg16","lab1105oracle");
			// return con;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			throw new CustCEException();
		}
	}

	public static DBUtil getInstance() throws CustCEException, Exception {
		// TODO Auto-generated method stub
		if (dbutil == null)
			dbutil = new DBUtil();

		return dbutil;
	}

}
