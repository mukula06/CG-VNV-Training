package com.Ma.valid;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataValidator {

	public boolean Datavalidate(String pattern,String str)
	{
		Pattern pat=Pattern.compile(pattern);
		Matcher matcher=pat.matcher(str);
		return matcher.matches();
		
	}
}
