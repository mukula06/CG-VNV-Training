package com.Ma.valid;

import static org.junit.Assert.*;

import com.Ma.Cust.*;
import com.Ma.dao.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class JUnitDB {
	int res;

	@Before
	public void setUp() throws Exception {
		Customer c=new Customer(123, "Mukul", "POSTPAID","9999999999");
		DBHelper db=new DBHelper();
		res=db.addCustomer(c);
	}

	@After
	public void tearDown() throws Exception {
		res=0;
		System.out.println("tear down invoked");
	}

	@Test
	public void test() {
		System.out.println("TEST DONE ");
		assertTrue(res!=0);
	
	}

}
