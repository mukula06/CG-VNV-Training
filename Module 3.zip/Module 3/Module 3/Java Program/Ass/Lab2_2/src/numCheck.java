import java.util.Scanner;


public class numCheck {

	public static void main (String[] args) {
		Scanner Num1 = new Scanner(System.in);
		System.out.println("Enter the number you want to check:\n");
		int key = Num1.nextInt();
		if (key<0)
		{
			System.out.println("Entered number is Negative number!!");
		}
		else if (key>0)
		{
			System.out.println("Entered number is Positive number!!");
		}
		else
		{
			System.out.println("NENO i.e Neither Negative nor Positive i.e. 0!!");
		}
	}
}
