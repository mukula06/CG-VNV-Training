
public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person Per = new Person("Mukul","Agrawal",'M');
		System.out.println("Personal Details:");
		System.out.println("__________________");
		System.out.println("First Name: "+Per.getFirstName());
		System.out.println("Last Name: "+Per.getLastName());
		System.out.println("Gender: "+Per.getGender());

	}

}
