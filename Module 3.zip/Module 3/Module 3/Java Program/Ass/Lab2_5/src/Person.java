import java.util.Scanner;


public class Person {

	String firstName, lastName;
	
	static long mNumber;

	
	public Person() {
		
	}
	
	public Person(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
		//this.gender = gender;
	}
	
	public String getFirstName() {
		return firstName;
	}
	/*public void setFirstName(String firstName) {
		this.firstName = firstName;
	}*/
	public String getLastName() {
		return lastName;
	}
	/*public void setLastName(String lastName) {
		this.lastName = lastName;
	}*/
	/*public char getGender() {
		return gender;
	}*/
	/*public void setGender(char gender) {
		this.gender = gender;
	}*/
	public void accNum() {
		Scanner Numb = new Scanner(System.in);
		mNumber = Numb.nextLong();
	}
	
	/*public void accGen() {
		Scanner Nu = new Scanner(System.in);
		gender = Nu.next().charAt(0);
	}*/
	
	public void showDetail() {
		Person Per = new Person("Mukul","Agrawal");
		
		System.out.println("Enter Mobile number: ");
		Per.accNum();
		
		
		System.out.println("");
		System.out.println("");
		System.out.println("Personal Details:");
		System.out.println("__________________");
		System.out.println("First Name: "+Per.getFirstName());
		System.out.println("Last Name: "+Per.getLastName());
		System.out.println("Mobile no. : "+mNumber);
		
	}
}
