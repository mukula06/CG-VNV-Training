import java.util.Scanner;

import Person.Gende;


public class PersonMain {
	static char gender;
	public static enum Gende {M,F;}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person Pe = new Person();
		System.out.println("Enter Gender: ");
		//Pe.accGen();
		Scanner Nu = new Scanner(System.in);
		gender = Nu.next().charAt(0);
		
		Gende m = Gende.M;
		Gende f = Gende.F;
		
		if (m==gender || f==gender)
		{
		
		Pe.showDetail();
		}
		else
			System.out.println("Enter valid Gender");

	}

}
