
public class Account /*extends Person*/ {

	long accNum;
	double balance, withd, depos;
	Person accHolder;
	
	
	/*public Account() {
	
	}*/
	
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	
	public void deposit (double depos) {
		this.depos=depos;
	}
	
	public double deposit () {
		 return depos;
	}
	
	public void withdraw (double withd) {
		this.withd= withd;
	}
	
	public double withdraw () {
		return withd;
	}
	
	public double updBalDepos () {
		return balance+depos;
	}
	
	public double updBalWith () {
		return balance-withd;
	}
}
