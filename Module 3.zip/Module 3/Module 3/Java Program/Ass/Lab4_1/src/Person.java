
public class Person {
	String name;
	float age;
	int AccountNum;
	
	public Person() {
		//super();
	}
	
	public Person(String name, float age, int AccountNum) {
		this.AccountNum = AccountNum;
		this.name = name;
		this.age = age;
	}
	
	public String getName() {
		return name;
	}
	
	
	public float getAge() {
		return age;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
	

}
