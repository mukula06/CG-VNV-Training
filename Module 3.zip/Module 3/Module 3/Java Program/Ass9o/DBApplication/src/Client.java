import java.util.Scanner;

/**
 * 
 */

/**
 * @author mukagraw
 *
 */
public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		Employee employee = new Employee();
		String option = "y";
		do {
			System.out.println("Enter your choice:\n1.Add\n2.View\n3.Update\n4.Delete\n");
			int choice = scanner.nextInt();
			String opt = "y";
			switch(choice) {
			case 1:
			do {	
				System.out.println("Enter employee name:");
				employee.setEName(scanner.next());
				System.out.println("Enter employee Id:");
				employee.setEId(scanner.nextInt());
				System.out.println("Enter employee salary:");
				employee.setSalary(scanner.nextLong());
				System.out.println("Do you want to add another emplyee detail?");
				opt = scanner.next();
				}while(opt.equals("y") || opt.equals("Y"));
					break;
			case 2:
				employee.showDetail();
				break;
			case 3:
				break;
			default:
				break;
			}
			System.out.println("Do you want to take a choice?");
			option = scanner.next();
		}while(option.equals("y") || option.equals("Y"));
		
	}

}
