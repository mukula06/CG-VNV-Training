/**
 * 
 */

/**
 * @author mukagraw
 *
 */
public class Employee {

	private String EName;
	private int EId;
	private long Salary;
	/**
	 * 
	 */
	public Employee() {
		super();
	}
	/**
	 * @param eName
	 * @param eId
	 * @param salary
	 */
	public Employee(String eName, int eId, long salary) {
		super();
		EName = eName;
		EId = eId;
		Salary = salary;
	}
	/**
	 * @return the eName
	 */
	public String getEName() {
		return EName;
	}
	/**
	 * @param eName the eName to set
	 */
	public void setEName(String eName) {
		EName = eName;
	}
	/**
	 * @return the eId
	 */
	public int getEId() {
		return EId;
	}
	/**
	 * @param eId the eId to set
	 */
	public void setEId(int eId) {
		EId = eId;
	}
	/**
	 * @return the salary
	 */
	public long getSalary() {
		return Salary;
	}
	/**
	 * @param salary the salary to set
	 */
	public void setSalary(long salary) {
		Salary = salary;
	}
	/**
	 * Show detail of employee
	 */
	public void showDetail() {
		System.out.println("Employee name: "+this.EName);
		System.out.println("Employee ID: "+this.EId);
		System.out.println("Employee Salary: "+this.Salary);
		System.out.println();
	}
	
}
