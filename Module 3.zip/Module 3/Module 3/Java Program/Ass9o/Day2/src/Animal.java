
 public abstract class Animal {

	public abstract void talk ();
	
	public static void respirate() {
		System.out.println("Respiration is Common");
	}
}


class Dog extends Animal {
	@Override
	public void talk() {
		System.out.println("Bark!!");
	}
}


class Cat extends Animal {
	@Override
	public void talk() {
		System.out.println("asdf!!");
	}
}
