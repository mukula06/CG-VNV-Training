
public class Day4Error {
	public static void main(String[] args) {
		
	}
}
