
public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 a[] = new Animal[2];
		a[0] = new Dog();
		a[1] = new Cat();
		for (Animal animal: a) {
			animal.talk();
		}
		
		a[0].respirate();
	}

}
