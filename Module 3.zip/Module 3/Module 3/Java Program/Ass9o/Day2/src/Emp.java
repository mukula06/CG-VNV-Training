import java.io.Serializable;


public class Emp implements Serializable {
	int eid;
	String ename;
	float bSalary;
	static int ctr;
	
	public Emp()	{
		ctr++;
		System.out.println("\nThis is Constructor");
	}
	
	public Emp(int id, String name, float salary)	{
		ctr++;
		eid = id;
		ename = name;
		bSalary = salary;
		System.out.println("\nParameter Cont Called");
	}
	
	public void showCounter() {
		System.out.println("No of objects are: "+ctr);
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Emp [eid=" + eid + ", ename=" + ename + ", bSalary=" + bSalary
				+ "]";
	}

	public void showSalary() {
		System.out.println("\nSalary is : "+bSalary);
	}
	
	/*public void setData(int id, String name, float salary) {
		eid = id;
		ename = name;
		bSalary = salary;
	}
	*/
	
	@Override
	public void finalize() {
		System.out.println("gc runs... object collected as garbage");
	}
	
	public int getEid() {
		return eid;
	}
	
	public void showData() {
		System.out.println("\nEmployee Name: "+ename+"   Employee Id: "+eid);
	}
}
