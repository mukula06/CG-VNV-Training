
public class Mgr extends Emp {

	float allow;
	
	public Mgr() {
		
	}

	public Mgr(int id, String name, float salary, float allow) {
		super(id, name, salary);
		// TODO Auto-generated constructor stub
		this.allow=allow;
	}
	
	public void showSalary() {
		System.out.println("\nManager Salary is : "+(bSalary+allow));
	}
}
