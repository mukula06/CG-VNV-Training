
public interface Printable {

	public return_type name() {
		
	}
}
