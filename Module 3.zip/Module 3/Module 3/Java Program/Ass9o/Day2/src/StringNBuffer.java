

public class StringNBuffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StringBuffer sb=new StringBuffer("Hello ");
		System.out.println(System.currentTimeMillis());
		for (long i = 0;i<10000000;i++)
		{
			sb.append('b');
		}
		System.out.println(System.currentTimeMillis());
		
		String s=new String("Hello ");
		System.out.println(System.currentTimeMillis());
		for (long i = 0;i<10000000;i++)
		{
			s="Hello"+"b";
		}
		System.out.println(System.currentTimeMillis());
		
	}

}

