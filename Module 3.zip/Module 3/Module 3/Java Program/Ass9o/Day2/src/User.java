
public class User {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//int ar1[]={2,5,6};
		//Emp empList[] = {new Emp(2,"Mkl",121),new Mgr(2,"Mkl",12121,15000)};
		/*Emp empList[] = new Emp[2];
		
		empList[0] = new Emp(2,"Mkl",121);
		empList[1] = new Mgr(2,"Mkl",12121,15000);
				
		for (int i=0;i<empList.length;i++)
		{
			empList[i].showSalary();
		}
		
		System.out.println(empList[0]);
		System.out.println(empList[1]);*/
		
		Emp e1 = new Emp(2,"Mkl",121);
		Emp e2 = new Emp(2,"Mkl",121);
		//e1 =e2;
		System.gc();
		//Emp e2 = new Mgr(2,"Mkl",12121,15000);
		//e1.setData(12345, "Mukul", 50000);
		
		/*e2.showData();
		e1.showSalary();
		e2.showSalary();*/
		
		/*int id = e1.getEid();
		System.out.println("Employment id is: "+id);
		
		
		e2.showData();
		e1.showData();
		e1.showCounter();*/
	}

}
