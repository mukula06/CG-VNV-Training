
public class salesMgr extends Mgr {

	float comm;
	
	public salesMgr(int id, String name, float salary, float allow, float comm) {
		super(id, name, salary, allow);
		// TODO Auto-generated constructor stub
		this.comm=comm;
	}

	public salesMgr() {
		System.out.println("Parameterless constructor is Called");
	}
	
}
