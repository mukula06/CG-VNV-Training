import java.util.Scanner;

/**
 * 
 * @author mukagraw
 *
 */
public class Person {

	String firstName, lastName;
	static long mNumber;
	private String gender;

	
	
	
	public void accNum() {
		Scanner Numb = new Scanner(System.in);
		mNumber = Numb.nextLong();
	}
	
	/*public void accGen() {
		Scanner Nu = new Scanner(System.in);
		gender = Nu.next().charAt(0);
	}*/
	
	/**
	 * 
	 */
	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	/**
	 * @param firstName
	 * @param lastName
	 */
	public Person(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	
	

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the mNumber
	 */
	public static long getmNumber() {
		return mNumber;
	}

	/**
	 * @param mNumber the mNumber to set
	 */
	public static void setmNumber(long mNumber) {
		Person.mNumber = mNumber;
	}
	
	public void showDetail() {
		System.out.println("Enter Mobile number: ");
		this.accNum();
		
		
		System.out.println("");
		System.out.println("");
		System.out.println("Personal Details:");
		System.out.println("__________________");
		System.out.println("First Name: "+this.getFirstName());
		System.out.println("Last Name: "+this.getLastName());
		System.out.println("Mobile no. : "+this.getmNumber());
		System.out.println("Gender :" + this.gender);
		
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
}
