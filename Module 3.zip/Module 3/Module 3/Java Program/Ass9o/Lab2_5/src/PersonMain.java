import java.util.Scanner;

public class PersonMain {
	// static char gender;
	public enum Gender {
		M, F
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		// Person Pe = new Person();
		System.out.println("Enter Gender: ");
		String gender = scanner.next();
		Gender genderEnum = null;
		try {
			genderEnum = Gender.valueOf(gender);
		} catch (Exception e) {
			System.out.println("Error");
		}

		Person person = new Person();

		person.setFirstName("Mukul");
		person.setLastName("Agrawal");
		person.setGender(genderEnum.toString());
		person.showDetail();

		// Pe.accGen();

		// gender = Nu.next().charAt(0);

		// Gende m = Gende.M;
		// Gende f = Gende.F;

		/*
		 * if (m==gender || f==gender) {
		 * 
		 * Pe.showDetail(); } else System.out.println("Enter valid Gender");
		 * 
		 * }
		 */

	}
}
