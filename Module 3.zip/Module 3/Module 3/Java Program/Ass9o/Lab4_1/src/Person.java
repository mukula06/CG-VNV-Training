
public class Person {
	String name;
	float age;
	
	public Person(String name, float age) {
		//this.AccountNum = AccountNum;
		this.name = name;
		this.age = age;
	}
	
	public String getName() {
		return name;
	}
	
	
	public float getAge() {
		return age;
	}

	@Override
	public String toString() {
		return "Person Name= " + name + "\nage= " + age;
	}
	

}
