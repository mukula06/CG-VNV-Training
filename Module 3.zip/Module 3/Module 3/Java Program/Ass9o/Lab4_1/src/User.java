public class User {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Person Sm12 = new Person("Mukul", (float) 12.2, 123);
		Account Sm1 = new Account();
		Sm1.setAccHolder(new Person("Smith", (float) 12.2));
		Sm1.setBalance(2000);
		Sm1.deposit(2000);
		Sm1.updBalDepos();

		Account Sm2 = new Account();
		Sm2.setAccHolder(new Person("Kathy", (float) 20.2));
		Sm2.setBalance(3000);
		Sm2.withdraw(2000);
		Sm2.updBalWith();

		System.out.println(Sm1.getAccHolder() + "\nAccount Number: "
				+ Sm1.getAccNum() + "\nCurrent Balance: " + Sm1.getBalance()
				+ "\nDeposit Amount: " + Sm1.deposit() + "\nUpdated Balance: "
				+ Sm1.updBalDepos());
		System.out.println("\n" + Sm2.getAccHolder() + "\nAccount Number: "
				+ Sm2.getAccNum() + "\nCurrent Balance: " + Sm2.getBalance()
				+ "\nWithdral Amount: " + Sm2.withdraw()
				+ "\nUpdated Balance: " + Sm2.updBalWith());

	}

}
