class Account
{
	int Id,Bal;
	String name;
	
	public void setAcc(int I, String n, int B)
	{
		Id=I;
		name=n;
		Bal=B;
	}
	
	public void withdraw(int B)
	{
		Bal=Bal-B;
	}
	
	public void deposit(int D)
	{
		Bal=Bal+D;
	}
	
	public void showAcco()
	{
		System.out.println("Name: "+name+"\nAccId: "+Id);
		System.out.println("Updated Balance is:"+Bal);
	}
}