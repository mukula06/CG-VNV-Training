class Date
{
	int dd,mm,yy;
	public void setDate(int d, int m, int y)
	{
		dd=d;
		mm=m;
		yy=y;
	}
	
	public void showDate()
	{
		System.out.println("Date is: "+dd+","+mm+","+yy);
	}
	
	public static void main (String args[])
	{
		Date doj = new Date();
		doj.showDate();
		doj.setDate(12,9,2016);
		doj.showDate();
		Date dob = new Date();
		dob.showDate();
		dob.setDate(29,9,1994);
		dob.showDate();
		System.out.println();
		Account emp = new Account();
		emp.setAcc(123,"Mukul",12000);
		emp.showAcco();
		emp.withdraw(1000);
		emp.showAcco();
		emp.deposit(300);
		emp.showAcco();
	}
}

class Account
{
	int Id,Bal;
	String name;
	
	public void setAcc(int I, String n, int B)
	{
		Id=I;
		name=n;
		Bal=B;
	}
	
	public void withdraw(int B)
	{
		Bal=Bal-B;
	}
	
	public void deposit(int D)
	{
		Bal=Bal+D;
	}
	
	public void showAcco()
	{
		System.out.println("Name: "+name+"\nAccId: "+Id);
		System.out.println("Updated Balance is:"+Bal);
	}
}