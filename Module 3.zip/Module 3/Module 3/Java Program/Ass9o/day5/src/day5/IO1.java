/**
 * 
 */
package day5;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * @author mukagraw
 *
 */
public class IO1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileOutputStream fos = new FileOutputStream("f11");
		
		BufferedInputStream bis = new BufferedInputStream(System.in);
		
		char x ='a';
		while (x != 'z') {
			x = (char) bis.read();
			fos.write(x);;
			System.out.print(x);
		}
		FileInputStream fis = new FileInputStream("f11");
		FileOutputStream fos1 = new FileOutputStream("f12");
		int i = 1;
		while (i != -1)
		{
			i=fis.read();
			fos1.write(i);
			System.out.print((char)i);
		}
	}

}
