package com.MA.ChotaBhim;
import com.MA.dao.*;
import com.MA.*;
/**
 * 
 */

/**
 * @author mukagraw
 *
 */
public class Employee {

/**
 * @author mukagraw
 * 
 */


	private String EName;
	private long EId, Salary;


	/**
	 * 
	 */
	public Employee() {
		super();
	}

	/**
	 * @param eName
	 * @param eId
	 * @param salary
	 */
	public Employee(String eName, long eId, long salary) {
		super();
		EName = eName;
		EId = eId;
		Salary = salary;
	}

	/**
	 * @return the eName
	 */
	public String getEName() {
		return EName;
	}

	/**
	 * @param eName
	 *            the eName to set
	 */
	public void setEName(String eName) {
		EName = eName;
	}

	/**
	 * @return the eId
	 */
	public long getEId() {
		return EId;
	}

	/**
	 * @param eId
	 *            the eId to set
	 */
	public void setEId(long eId) {
		EId = eId;
	}

	/**
	 * @return the salary
	 */
	public long getSalary() {
		return Salary;
	}

	/**
	 * @param salary
	 *            the salary to set
	 */
	public void setSalary(long salary) {
		Salary = salary;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Client [EName=" + EName + ", EId=" + EId + ", Salary=" + Salary
				+ "]";
	}

}