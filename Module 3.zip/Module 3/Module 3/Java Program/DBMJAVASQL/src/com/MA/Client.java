package com.MA;

import com.MA.dao.*;
import com.MA.ChotaBhim.*;
import com.MA.exception.*;

import java.sql.SQLException;
import java.util.Scanner;

/**
 * 
 */
/**
 * 
 * @author mukagraw
 * 
 */
public class Client {

	/**
	 * @param args
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public static void main(String[] args) throws ClassNotFoundException,
			SQLException, ExcCrud {
		try { 
			Scanner scanner = new Scanner(System.in);
			Client dataS = new Client();
			DataStore DS = new DataStore();
			String option = "y";
			
			do {
				System.out
						.println("Enter your choice:\n1.Add\n2.View\n3.Delete\n4.exit\n");
				int choice = scanner.nextInt();
				if (choice > 4) {
					throw new ExcCrud();
				}
				String opt = "y";
				switch (choice) {
				case 1:
					do {
						DS.addTab();
						System.out.println();
						System.out
								.println("Do you want to add another emplyee detail?");
						opt = scanner.next();
						
					} while (opt.equals("y") || opt.equals("Y"));
					System.out.println("Do you want to take a choice?");
					option = scanner.next();
					
					break;
				case 2:
					do {
						System.out.println("Please Enter Employee Id:");
						Long id = scanner.nextLong();
						DS.showDetail(id);
						System.out.println();
						System.out
								.println("Do you want to search another emplyee detail?");
						opt = scanner.next();
					} while (opt.equals("y") || opt.equals("Y"));
					System.out.println("Do you want to take a choice?");
					option = scanner.next();
					break;

				case 3:
					do {
						System.out
								.println("Please Enter Employee Id for deleting detail:");
						Long epid = scanner.nextLong();
						DS.deleteDetail(epid);
						System.out.println();
						System.out
								.println("Do you want to delete another emplyee detail?");
						opt = scanner.next();
					} while (opt.equals("y") || opt.equals("Y"));
					System.out.println("Do you want to take a choice?");
					option = scanner.next();
					break;
				default:
					option = "N";
					break;
				}

			} while (option.equals("y") || option.equals("Y"));
			

		} catch (ExcCrud e) {
			
			System.out.println("sdfg "+e);
		}
	}

}
