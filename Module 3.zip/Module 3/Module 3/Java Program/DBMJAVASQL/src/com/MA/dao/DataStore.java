package com.MA.dao;
import com.MA.*;
import com.MA.ChotaBhim.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.MA.ChotaBhim.Employee;

/**
 * 
 */

/**
 * 
 * @author mukagraw
 * 
 */
public class DataStore {

	public DataStore() throws ClassNotFoundException, SQLException {
		System.out.println("con123");
		Class.forName("oracle.jdbc.driver.OracleDriver");
		System.out.println("con");
		Connection connection = DriverManager.getConnection(
				"jdbc:oracle:thin:@10.125.6.62:1521:Orcl11g", "lab1105trg18",
				"lab1105oracle");

	}

	public void addTab() throws SQLException {
		Connection connection = DriverManager.getConnection(
				"jdbc:oracle:thin:@10.125.6.62:1521:Orcl11g", "lab1105trg18",
				"lab1105oracle");
		Scanner scanner = new Scanner(System.in);
		Employee dataS = new Employee();
		System.out.println("Enter employee name:");
		dataS.setEName(scanner.next());
		System.out.println("Enter employee Id:");
		dataS.setEId(scanner.nextLong());
		System.out.println("Enter employee salary:");
		dataS.setSalary(scanner.nextLong());
		Statement st = connection.createStatement();
		st.executeUpdate("INSERT INTO Mukul VALUES (" + dataS.getEId() + ", '"
				+ dataS.getEName() + "', " + dataS.getSalary() + ")");
	}

	public void showDetail(Long epid) throws SQLException {
		Connection connection = DriverManager.getConnection(
				"jdbc:oracle:thin:@10.125.6.62:1521:Orcl11g", "lab1105trg18",
				"lab1105oracle");
		Statement st = connection.createStatement();
		ResultSet logindata = st
				.executeQuery("Select * from Mukul where eid = " + epid);
		while (logindata.next()) {
			System.out.println("EmployeeId Name Salary");
			System.out.println(logindata.getLong(1) + "        "
					+ logindata.getString(2) + "  " + logindata.getLong(3));
		}
	}
	
	public void deleteDetail(Long epid) throws SQLException {
		Connection connection = DriverManager.getConnection(
				"jdbc:oracle:thin:@10.125.6.62:1521:Orcl11g", "lab1105trg18",
				"lab1105oracle");
		Statement st = connection.createStatement();
		st.executeUpdate("Delete from Mukul where eid = " + epid);
		
	}

}
