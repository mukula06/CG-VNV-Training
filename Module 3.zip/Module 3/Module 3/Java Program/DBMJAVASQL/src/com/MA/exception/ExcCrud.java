package com.MA.exception;

public class ExcCrud extends Exception {

	public ExcCrud () {
		
	}
	
	@Override
	public String toString() {
		
		
		return "EmpCRUDException ,Database operation failed ";
	
			
	}
}
