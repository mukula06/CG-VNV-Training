import java.sql.*;

/**
 * 
 */

/**
 * @author mukagraw
 * 
 */
public class JDBCDemo {

	/**
	 * @param args
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public static void main(String[] args) throws ClassNotFoundException,
			SQLException {
		// TODO Auto-generated method stub
		Class.forName("oracle.jdbc.driver.OracleDriver");
		System.out.println("con");
		Connection connection = DriverManager.getConnection(
				"jdbc:oracle:thin:@10.125.6.62:1521:Orcl11g", "lab1105trg18",
				"lab1105oracle");
		System.out.println("connection");
		Statement st = connection.createStatement();
		st.executeUpdate("INSERT INTO EMP VALUES (7369, 'STH',  'CLERK',     7902, TO_DATE('17-DEC-1980', 'DD-MON-YYYY'),  800, NULL, 20)");
		ResultSet logindata = st.executeQuery("Select * from Emp");
		while (logindata.next()) {
			System.out.println(logindata.getInt(1) + logindata.getString(2));
		}

	}

}
