package com.sj;
import java.util.Scanner;

import com.sj.dao.DataStoreHelper;
import com.sj.exception.EmpCRUDException;
import com.sj.model.Employee;



/**
 * 
 */

/**
 * @author sangeeta
 *
 */
public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
		Scanner scanner = new Scanner(System.in);
		int cnt=1;
		int id;String name;
		String option="Y";
		do
		{
			System.out.println("Please enter your choice: 1:Add 2:View 3:Exit");
		  cnt =   scanner.nextInt();
		  
		  
		  String opt = "Y";
		  Employee dummy = new Employee();
		  switch(cnt)
		  {
		  case 1:do
		        {System.out.println("Enter eid");
		            int i=scanner.nextInt();
		       dummy.setId( i );
		       System.out.println("Enter ename");
		          String n =scanner.next();
		       dummy.setName(n);
		       System.out.println("Enter salary");
		           double sal =scanner.nextDouble();
		       dummy.setSalary(sal);
		      System.out.println("you entered "+i +n+dummy);
		       DataStoreHelper.addEmployee(dummy);
		       System.out.println("Do you want to add more employees?");
		       opt=  scanner.next();
		        
		        }while(opt.equals("Y")||opt.equals("y"));
		    	 
		          break;
		  case 2: do{
			      System.out.println("Enter empno you want to see ");
		          int eid = scanner.nextInt();
		          Employee employee=DataStoreHelper.viewEmployee(eid);
		          System.out.println("Employee details"+employee);
		          System.out.println("Do you want to continue viewing?");
			       option=  scanner.next();
		           }while(option.equals("Y")||option.equals("y"));
		          break;
		        
		  default: 
			  {  System.out.println("Exiting..");
				  System.exit(0);
			  }
		  
		  
		  
		  }
		  System.out.println("Do you want to continue?..enter -1 to exit1");
		  option =scanner.next();
		  //cnt =  scanner.nextInt();
		  
		  }while(option.equals("Y")||option.equals("y"));
		
		System.out.println("exiting...");
		
		}
	
	catch(EmpCRUDException e)
	{
		
			System.out.println("Exception occured"+e);
		
	}
	catch (Exception e)
	{
	    	System.out.println("Something went wrong..exiting..");
    }
	
		
	}
		
		
		
		//char c =scanner.nextChar();

	}


