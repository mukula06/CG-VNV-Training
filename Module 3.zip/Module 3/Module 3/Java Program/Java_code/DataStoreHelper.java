/**
 * 
 */
package com.sj.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.sj.exception.EmpCRUDException;
import com.sj.model.Employee;

/**
 * @author sangeeta
 *
 */
public class DataStoreHelper {
   
//static ArrayList <Employee> emplist=new ArrayList<Employee>();
    public DataStoreHelper() {
	super();
	// emplist =new ArrayList();
	// TODO Auto-generated constructor stub
	
    }
   public static void addEmployee(Employee e)throws EmpCRUDException
   {
	     Connection con=null;
	         try {
	        	  con =  DBUtil.getInstance().getConnection();
				PreparedStatement st = con.prepareStatement("insert into emp values(?,?,?)");
				  int eid =  e.getId();
				  String ename=  e.getName();
				   double salary= e.getSalary();
				   System.out.println(eid);
				   st.setInt(1, eid);
				   st.setString(2, ename);
				   st.setDouble(3, salary);
			int row=	st.executeUpdate();
			     if (row !=1)
			    	 throw new EmpCRUDException();
			     else
			    	 System.out.println("Employee inserted");
	         } catch (SQLException e1) {
				// TODO Auto-generated catch block
	        	// e1.printStackTrace();
	        	 throw new EmpCRUDException();
			}
	         finally{
	        	 
	        	 try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					throw new EmpCRUDException();
				}
	         }
	 
	// emplist.add(e);
   }
   
   public static Employee viewEmployee(int id)throws EmpCRUDException
   {
	   Connection con = null;
       try {
    	  // System.out.println("id"+id);
    	    con =  DBUtil.getInstance().getConnection();
	       
	       PreparedStatement st = con.prepareStatement("select * from emp where eid = ?");
		  st.setInt(1, id);
	ResultSet rs=	st.executeQuery();
	Employee e1 = new Employee();
	if (rs != null)
	       {
		      rs.next();
	    	 e1.setId(rs.getInt(1));
	         e1.setName(rs.getString(2));
	         e1.setSalary(rs.getDouble(3));
	        }
	          else
	    	 throw new EmpCRUDException();
	          return e1;
         } 
       catch (SQLException e) {
		// TODO Auto-generated catch block
    	    // e.printStackTrace();
 	           throw new EmpCRUDException();
       	}
        finally{
        	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new EmpCRUDException();
			}
        }
       

	   
	   
	   
	   
	   
	   
	   
	  //Employee employee = emplist.get(x);
	  //return employee;
   }
   
   
}
