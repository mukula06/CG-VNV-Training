/**
 * 
 */
package com.sj.exception;

import java.sql.SQLException;

/**
 * @author sangeeta
 *
 */
public class EmpCRUDException extends SQLException{

	/**
	 * 
	 */
	public EmpCRUDException() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		
		
		return "EmpCRUDException ,Database operation failed ";
	
			
	}
	
	

}
