/**
 * 
 */
package com.sj.model;

/**
 * @author sangeeta
 *
 */
public class Employee {
   int id;
   String name;
   public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
double salary;
   public void showEmpData()
   {
	   System.out.println("Emp Details"+id+name);
	   
	   
   }
   public Employee()
   {
	   //System.out.println("emp paramless constr");
   }
   
   
   
   @Override
public String toString() {
	return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
}
public Employee(int id, String name, double salary) {
	
	this.id = id;
	this.name = name;
	this.salary = salary;
	//System.out.println("emp param constr");
}
public void cal_salary()
   {
	   System.out.println("Emp salary:"+ salary);
   }  
   
}

class Manager extends Employee
{
	double allowance;
	
	
	
	public Manager() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("mgr paramless constr");
	}



	public Manager(int id, String name, double salary,double allowance) {
		super(id, name, salary);
		// TODO Auto-generated constructor stub
		
		this.allowance = allowance;
		System.out.println("mgr param constr");
	}
	
	public void cal_salary()
	   {
		   System.out.println("Mgr salary:"+ (salary+allowance));
	   }  
	
	public void showAllow()
	{
		System.out.println("allow:"+allowance);
	}
	
	
}








