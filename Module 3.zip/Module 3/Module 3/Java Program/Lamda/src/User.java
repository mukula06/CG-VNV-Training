/**
 * 
 */

/**
 * @author mukagraw
 *
 */
public class User {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MaxInit Find = (int n1, int n2) -> n1>n2?n1:n2;
	}

}
