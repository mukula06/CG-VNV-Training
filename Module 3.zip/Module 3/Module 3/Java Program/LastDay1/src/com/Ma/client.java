/**
 * 
 */
package com.Ma;

/**
 * @author mukagraw
 *
 */
public class client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
