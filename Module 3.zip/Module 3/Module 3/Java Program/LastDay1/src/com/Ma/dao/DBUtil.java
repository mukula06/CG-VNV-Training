/**
 * 
 */
package com.Ma.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.Ma.exception.EmpCRUDException;


/**
 * @author sangeeta
 *
 */
public class DBUtil {
     static DBUtil dbutil;
	/**
	 * @throws EmpCRUDException 
	 * 
	 */
	private DBUtil() throws EmpCRUDException {
		// TODO Auto-generated constructor stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
		    } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
		    	//e.printStackTrace();
			throw new EmpCRUDException();
		}
	}
	
	public static DBUtil getInstance() throws EmpCRUDException
	{
		if (dbutil==null)
			dbutil=new DBUtil();
		return dbutil;
	}
	
	public Connection getConnection() throws EmpCRUDException
	{
		try {
			return( DriverManager.getConnection("jdbc:mysql://localhost:3306/empdb","root","root"));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new EmpCRUDException();
		}
	}

}
