/**
 * 
 */
package com.Ma.dao;

/**
 * @author mukagraw
 *
 */
public class DataStore {

}
