/**
 * 
 */
package com.Ma.sam;

/**
 * @author mukagraw
 *
 */
public class Employee {

}
