package com.Ma.test;

import java.sql.Connection;

import com.Ma.dao.DBUtil;
import com.Ma.exception.EmpCRUDException;

public class TestDBUtil {
     Connection con;
     DBUtil testInstance;
	@Before
	public void setUp() throws Exception {
		
		testInstance = DBUtil.getInstance();
	}

	@After
	public void tearDown() throws Exception {
	 
		con.close();
	    testInstance =null;
	    System.out.println("tear down invoked");
	}

	@Test
	public void testGetConnection() {
		
		try {
			con =testInstance.getConnection();
			assertTrue(con != null);
		    } catch (EmpCRUDException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//fail("Not yet implemented"); // TODO
	}

}
