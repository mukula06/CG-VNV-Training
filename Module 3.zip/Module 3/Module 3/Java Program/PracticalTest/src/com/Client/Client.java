package com.Client;
import java.sql.SQLException;
import java.util.Scanner;

import com.dao.DataStoreHelper;
import com.model.Emp;


public class Client {
	public static void main(String[] args) throws Exception
	{
	
	int i=0;	
	Scanner sc= new Scanner(System.in);	
	Emp dm=new Emp();
	boolean y=true;
	
	do{
		System.out.println("Enter your choice    1.Add  2.View  3.View Table 4.Update  5.Delete");
         i=sc.nextInt();
         
	switch(i){
	
	case 1 :boolean y1=true;
			do{
			System.out.println("Enter your name");
	        dm.setEname(sc.next());
			System.out.println("Enter your EID");
			dm.setEid(sc.nextInt());
			System.out.println("Enter your salary");
			dm.setEsalary(sc.nextInt());
			DataStoreHelper.createEmp(dm);
		
			System.out.println("do you to add more records? y/n");
		    String x=sc.next();
		    char ch=x.charAt(0); 
		    if( ch=='n')
		    y1=false;
			}while(y1!=false);
			break;
			
	case 2 :Emp ee=DataStoreHelper.Viewemployee(2);
		System.out.println(ee);
			break;
			
	case 3 :System.out.println("Displaying all Employees data");
	        DataStoreHelper.Viewemployee1();
			break;
			
	case 4 :DataStoreHelper.Update(2);
		    break;
	
	case 5 :
		    DataStoreHelper.delete(2);
			break;
	
	default :System.out.println("Updating your data");
	
	}			
	System.out.println("want to process for another choices? y/n");
    String x=sc.next();
    char ch=x.charAt(0); 
    if( ch=='n')
    y=false;
	}while(y!=false);
	
	}
	
	}
