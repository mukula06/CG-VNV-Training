package com.Exp;

public class Customexception extends Exception {
	

	public Customexception() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		
		
		return "CustomException ,Database operation failed ";
	
			
	}
}
