package com.dao;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

import com.Exp.Customexception;

//import com.sj.exception.EmpCRUDException;



public class DBUtil {
static DBUtil dbutil;
static Connection conn;
static Properties props;
static String url,uid,pass;

private DBUtil() throws Customexception, Exception
{
	try {
		props =new Properties();
		FileInputStream fis = null;
		fis = new FileInputStream("db.properties");
		props.load(fis);
		
		BasicConfigurator.configure();
		Logger log=Logger.getLogger(DBUtil.class);
		log.debug("Hello this is a debug message");
	    log.info("Hello this is an info message"); 
		
		Class.forName(props.getProperty("DB_DRIVER_CLASS"));
		
		
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		throw new Customexception();
	}
	}
	public static Connection getConnection() throws Customexception, Exception {
		// TODO Auto-generated method stub
		
		try{
		 url= props.getProperty("DB_URL");
		  uid= props.getProperty("DB_USERNAME");
		   pass=props.getProperty("DB_PASSWORD");
		   return( DriverManager.getConnection(url,uid,pass));
		//Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.125.6.62:1521:Orcl11g","Lab1105trg16","lab1105oracle");
		//return con;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		//e.printStackTrace();
		throw new Customexception();
	}
	}

	public static DBUtil getInstance() throws Customexception, Exception{
		// TODO Auto-generated method stub
		if(dbutil==null)
			dbutil=new DBUtil();

		return dbutil;
	}

}
	



