package com.dao;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

import com.Exp.Customexception;
import com.model.Emp;


public class DataStoreHelper {

	public DataStoreHelper() {
		// TODO Auto-generated constructor stub
	}
	
	public static void createEmp(Emp e) throws Customexception, Exception
	{
		try{
		Connection con=DBUtil.getInstance().getConnection();
		Statement st=con.createStatement();
		int x=st.executeUpdate("INSERT INTO EMP1 VALUES ("+e.getEid()+",'"+e.getEname()+"',"+e.getEsalary()+")");
		System.out.println(x);
		}catch(Exception e1){
			e1.printStackTrace();
			System.out.println(e1);}
		
	}
	public static Emp Viewemployee(int id) throws Exception
	{
		Connection con=DBUtil.getInstance().getConnection();
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from Emp1 where EMPID = "+id);
		rs.next();
		Emp e=new Emp(rs.getInt(1),rs.getString(2), rs.getInt(3));
		return e;
		
	}	
	public static void Viewemployee1() throws Exception
	{
		Connection con=DBUtil.getInstance().getConnection();
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from Emp1");
		while(rs.next())
		{
			System.out.println(rs.getInt(1)+",          "+rs.getString(2)+",          "+rs.getInt(3));
		}	
	}
	
	
	public static void Update(int id) throws Exception
	{
		Connection con=DBUtil.getInstance().getConnection();
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("UPDATE EMP1 SET ENAME='roopal' WHERE EMPID="+id);
		System.out.println("your data have been Updated");						
				
	}
	
	public static void delete(int id) throws Exception
	{
		Connection con=DBUtil.getInstance().getConnection();
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("delete from EMP1 where EMPID= "+id);
		System.out.println("deleting your data");
	}	
}