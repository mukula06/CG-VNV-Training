package com.model;

public class Emp {
	 String ename;
	 int eid;
	 int esalary;
	@Override
	public String toString(){
		return("Name:"+ename+",id:"+eid+",salary"+esalary);
	}
	
public Emp(){}

public Emp(int id, String name, int salary){
	ename=name;
	eid=id;
	esalary=salary;
}
public void data(){
	System.out.println("Name:"+ename+",id:"+eid+",salary"+esalary);
}


/**
 * @return the ename
 */
public String getEname() {
	return ename;
}


/**
 * @param ename the ename to set
 */


/**
 * @return the eid
 */
public int getEid() {
	return eid;
}


/**
 * @param eid the eid to set
 */
public void setEid(int eid) {
	this.eid = eid;
}


/**
 * @return the esalary
 */
public double getEsalary() {
	return esalary;
}


/**
 * @param esalary the esalary to set
 */



public void setEsalary(int esalary) {
	this.esalary = esalary;
}

public void setEname(String ename) {
	this.ename = ename;
}


}