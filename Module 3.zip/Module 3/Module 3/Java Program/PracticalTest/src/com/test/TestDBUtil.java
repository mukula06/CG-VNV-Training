package com.test;

import static org.junit.Assert.*;

import java.sql.Connection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.dao.DBUtil;
import com.Exp.Customexception;

public class TestDBUtil {
     Connection con;
     DBUtil testInstance;
	@Before
	public void setUp() throws Exception {
		
		testInstance = DBUtil.getInstance();
	}

	@After
	public void tearDown() throws Exception {
	 
		con.close();
	    testInstance =null;
	    System.out.println("tear down invoked");
	}

	@Test
	public void testGetConnection() throws Exception {
		
		try {
			con =testInstance.getConnection();
			assertTrue(con != null);
		    } catch (Customexception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//fail("Not yet implemented"); // TODO
	}

}
