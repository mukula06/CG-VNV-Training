/**
 * 
 */
package test12;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author mukagraw
 *
 */
public class TestGreeting {

	greeting gret1;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		gret1 = new greeting();
		gret1.setMsg("Beta tum Mujhe zara bhi pasand nhi aye!!");
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link greeting#Gree()}.
	 */
	@Test
	public void testGree() {
		
		assertTrue(gret1.Gree().equals("Beta tum Mujhe zara bhi pasand nhi aye!!"));
	}

	
}
