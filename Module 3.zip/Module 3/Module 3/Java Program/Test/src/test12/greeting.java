package test12;
/**
 * 
 */

/**
 * @author mukagraw
 *
 */
public class greeting {

	String msg;

	/**
	 * @param msg
	 */
	public greeting(String msg) {
		super();
		this.msg = msg;
	}

	/**
	 * 
	 */
	public greeting() {
		super();
	}

	/**
	 * @return the msg
	 */
	public String getMsg() {
		return msg;
	}

	/**
	 * @param msg the msg to set
	 */
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public String Gree() {
		// TODO Auto-generated method stub

		return "Beta tum Mujhe zara bhi pasand nhi aye!!";
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((msg == null) ? 0 : msg.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		greeting other = (greeting) obj;
		if (msg == null) {
			if (other.msg != null)
				return false;
		} else if (!msg.equals(other.msg))
			return false;
		return true;
	}

	
}
