/**
 * 
 */
package com.mka.Simple;

/**
 * @author mukagraw
 *
 */
public class Lamda {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MaxInterface inits = (int n1, int n2)->n1>n2?n1:n2 ;
		int maxno = inits.MaxFin(8,13);
		System.out.println("Max no is: "+maxno);
	}

}
