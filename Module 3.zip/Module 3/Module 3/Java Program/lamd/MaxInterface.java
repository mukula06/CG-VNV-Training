/**
 * 
 */
package com.mka.Simple;

/**
 * @author mukagraw
 *
 */
@FunctionalInterface
public interface MaxInterface {

	
	public int MaxFin(int n1, int n2);
}
