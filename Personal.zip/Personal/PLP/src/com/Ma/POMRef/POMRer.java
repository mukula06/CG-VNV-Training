/**
 * 
 */
package com.Ma.POMRef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

/**
 * @author mukagraw
 *
 */
public class POMRer {

	WebDriver driver;
	WebElement element;
	Select select;
	
	By MyAccXpath	 = By.className("caret");
	By RegisterXpath = By.xpath("/html/body/nav/div/div[2]/ul/li[2]/ul/li[1]/a");
	By FirstId		 = By.id("input-firstname");
	By LastId		 = By.id("input-lastname");
	By EmailId		 = By.id("input-email");
	By FaxId		 = By.id("input-fax");
	By CompanyId 	 = By.id("input-company");
	By Address1Id	 = By.id("input-address-1");
	By Address2Id	 = By.id("input-address-2");
	By CityId		 = By.id("input-city");
	By PostCodeId	 = By.id("input-postcode");
	By TitleTag		 = By.tagName("title");
	By CountryId	 = By.id("input-country");
	By StateId 		 = By.id("input-zone");
	By PasswordId	 = By.id("input-password");
	By CnfrmPswrdId  = By.id("input-confirm"); 
	By AcceptXpat	 = By.xpath("/html/body/div[2]/div/div/form/div/div/input[1]");
	By ContinueXpath = By.xpath("/html/body/div[2]/div/div/form/div/div/input[2]");
	
	/**
	 * @param driver
	 */
	public POMRer(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public void registerClick() {
		driver.findElement(MyAccXpath).click();
		driver.findElement(RegisterXpath).click();
	}
	
	public void setFirstName(String FirstName) {
		driver.findElement(FirstId).sendKeys(FirstName);
	}
	
	public void setLastName(String LastName) {
		driver.findElement(LastId).sendKeys(LastName);
	}
	
	public void setEmailId(String EmailIDD) {
		driver.findElement(EmailId).sendKeys(EmailIDD);
	}
	
	public void setfax(String faxNo) {
		driver.findElement(FirstId).sendKeys(faxNo);
	}
	
	public void setCompany(String companyName) {
		driver.findElement(CompanyId).sendKeys(companyName);
	}
	
	public void setAddress1(String Address1) {
		driver.findElement(Address1Id).sendKeys(Address1);
	}
	
	public void setAddress2(String Address2) {
		driver.findElement(Address2Id).sendKeys(Address2);
	}
	
	public void setCity(String cityName) {
		driver.findElement(CityId).sendKeys(cityName);
	}
	
	public void setPostcode(String PostCode) {
		driver.findElement(PostCodeId).sendKeys(PostCode);
	}
	
	public void setCountry(String CountryName) {
		element = driver.findElement(CountryId);
		select  = new Select(element);
		select.selectByVisibleText(CountryName);
	}
	
	public void setState(String StateName) {
		element = driver.findElement(StateId);
		select  = new Select(element);
		select.selectByVisibleText(StateName);
	}
	
	public String PageTitle() {
		return driver.findElement(TitleTag).getText();
	}
	
	public void setPassword(String Password) {
		driver.findElement(PasswordId).sendKeys(Password);
	}
	
	public void setCnfrmPswrd(String CnfrmPassword) {
		driver.findElement(CnfrmPswrdId).sendKeys(CnfrmPassword);
	}
	
	public void AcceptAgreement() {
		if (!driver.findElement(AcceptXpat).isSelected()) {
			driver.findElement(AcceptXpat).click();
		}
	}
	
	public void continueClick() {
		driver.findElement(ContinueXpath).click();
	}
}
