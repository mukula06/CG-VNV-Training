/**
 * 
 */
package com.Ma.test;




import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Ma.pagefactory.Pagefact;


/**
 * @author mukagraw
 *
 */
public class testOpenCart {

	WebDriver driver;
	Pagefact page;
	
	@BeforeTest
	public void HomePageConfig () {
		driver	=	new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://demo.opencart.com/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page = new Pagefact(driver);
		page.registerClick();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@Test(priority=0)
	public void titleverify() {
		System.out.println(page.PageTitle());
		Assert.assertEquals(page.PageTitle(), "Register Account");
	}
	
	@Test(priority=1)
	public void FirstNa() {
		page.setFirstName("Muuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu");
		page.continueClick();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Assert.assertEquals(page.FrstErr(), "First Name must be between 1 and 32 characters!");
	}
	
	@AfterTest
	public void CloseBrow() throws InterruptedException {
		Thread.sleep(5000);
		driver.quit();
	}
}
