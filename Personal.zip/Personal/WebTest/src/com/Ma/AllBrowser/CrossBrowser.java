/**
 * 
 */
package com.Ma.AllBrowser;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 * @author mukagraw
 *
 */
public class CrossBrowser {

	WebDriver driver;
	@BeforeTest
	@Parameters("browser")
	public void setupTest(String browser) throws Exception {
		if (browser.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
		}
		
		else if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "D:\\Module 4\\Drivers\\New_Chrome_Driver\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		
		else if (browser.equalsIgnoreCase("ie")) {
			System.setProperty("webdriver.ie.driver", "D:\\Module 4\\Drivers\\New IE driver\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}
		
		else
			throw new Exception("No Browser specified");
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@Test
	public void OpenBrowser () {
		driver.get("http://demo.opencart.com");
	}
}
