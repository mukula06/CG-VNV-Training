package com.Ma.Chrome;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



/**
 * @author mukagraw
 *
 */
public class TestWeb {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "D:\\Module 4\\Drivers\\New_Chrome_Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		String baseurl="http://demo.opencart.com/";
		String ExpTit = "The OpenCart demo store";
		String ActTit = "";
		driver.get(baseurl);
		ActTit=driver.getTitle();
		
		if (ActTit.contentEquals(ExpTit)) {
			System.out.println("Test Pass");
		}
		else {
			System.out.println("Test Failed");
		}
		
		//driver.close();
	}

}