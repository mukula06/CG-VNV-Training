package com.Ma.JunitD;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class AnnotationDemo {

	@BeforeClass
	public static void init() {
		System.out.println("BeforeClass");
	}
	
	@Before
	public void initialize() {
		System.out.println("Before");
	}
	
	@Test
	public void a() {
		System.out.println("Test 1");
	}
	
	@Ignore
	@Test
	public void b() {
		System.out.println("Test 2");
	}
	
	@Test
	public void c() {
		System.out.println("Test 3");
	}

	@Test
	public void d() {
		System.out.println("Test 4");
	}

	@Test
	public void e() {
		System.out.println("Test 5");
	}
	
	@After
	public void Close() {
		System.out.println("After");
	}

	@AfterClass
	public static void Clo() {
		System.out.println("AfterClass");
	}
	

}
