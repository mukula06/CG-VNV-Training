/**
 * 
 */
package com.Ma.JunitD;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author mukagraw
 *
 */
public class Annotationone {

	@Before
	public void initialize() {
		System.out.println("Before");
	}
	
	@Test
	public void myTestMethod() {
		System.out.println("Test");
	}
	
	@After
	public void afterTest() {
		System.out.println("After");
	}

}
