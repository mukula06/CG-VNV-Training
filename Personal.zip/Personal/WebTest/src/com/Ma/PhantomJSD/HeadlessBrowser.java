/**
 * 
 */
package com.Ma.PhantomJSD;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;

/**
 * @author mukagraw
 *
 */
public class HeadlessBrowser {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("phantomjs.binary.path", "D:\\Module 4\\Drivers\\PhantomJS_Driver\\phantomjs.exe");
		WebDriver driver = new PhantomJSDriver();
		driver.get("file:///D:/Module%204/SeleniumSoft/Selenium%20Demos%20&%20Lab%20files/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/WorkingWithForms.html");
		//driver.get("http://demo.opencart.com/");
		System.out.println("Page title is: "+driver.getTitle());
	}

}
