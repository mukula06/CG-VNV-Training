package com.Ma.SeleniumRC;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class IERC {

	public static void main(String[] args) throws MalformedURLException {
		WebDriver driver = new RemoteWebDriver(new URL("http://10.102.54.39:5666/wd/hub"),DesiredCapabilities.internetExplorer());
		driver.get("http://demo.opencart.com");
	}
}
