/**
 * 
 */
package com.Ma.SeleniumRC;

import java.net.MalformedURLException;
import java.net.URL;

import org.junit.validator.PublicClassValidator;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 * @author mukagraw
 *
 */
public class RCDriverIE {

	WebDriver driver;
	String baseurl,nodeurl;
	
	@BeforeTest
	public void display() throws MalformedURLException {
		System.setProperty("webdriver.ie.driver", "D:\\Module 4\\Drivers\\New IE driver\\IEDriverServer.exe");
		
		baseurl = "file:///D:/Module%204/SeleniumSoft/Selenium%20Demos%20&%20Lab%20files/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/WorkingWithForms.html";
		
		nodeurl = "http://10.102.54.39:5666/wd/hub";
		DesiredCapabilities DC = new DesiredCapabilities().internetExplorer();
		DC.setBrowserName("internetExplorer");
		DC.setPlatform(Platform.WINDOWS);
		driver = new RemoteWebDriver(new URL(nodeurl), DC);
	}
	
	@AfterTest
	public void aftertest() {
		//driver.quit();
	}
	
	@Test
	public void simpletest() {
		driver.get(baseurl);
		Assert.assertEquals("Email Registration Form", driver.getTitle());
	}
}
