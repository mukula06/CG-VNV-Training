/**
 * 
 */
package com.Ma.Test;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * @author mukagraw
 *
 */
public class AlertDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		driver.get("file:///D:/Module%204/SeleniumSoft/Selenium%20Demos%20&%20Lab%20files/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/AlertExample.html");
		WebElement webelement = driver.findElement(By.name("btnAlert"));
		webelement.click();
		Alert alert = driver.switchTo().alert();
		String alertTxt = alert.getText();
		System.out.println("Alert text is: "+alertTxt);
		//alert.accept();
		//alert.dismiss();
	}

}
