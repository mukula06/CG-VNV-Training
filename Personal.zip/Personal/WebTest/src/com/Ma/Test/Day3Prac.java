/**
 * 
 */
package com.Ma.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

/**
 * @author mukagraw
 *
 */
public class Day3Prac {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		driver.get("file:///D:/Module%204/SeleniumSoft/Selenium%20Demos%20&%20Lab%20files/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/WorkingWithForms.html");
		
		driver.findElement(By.id("txtUserName")).sendKeys("Mukul");
		driver.findElement(By.id("txtPassword")).sendKeys("Mukul@123");
		driver.findElement(By.id("txtConfPassword")).sendKeys("Mukul@123");
		driver.findElement(By.id("txtFirstName")).sendKeys("Mukul");
		driver.findElement(By.id("txtLastName")).sendKeys("Agrawal");
		driver.findElement(By.cssSelector("input[value='Male']")).click();
		driver.findElement(By.id("DOB")).sendKeys("06/09/1994");
		driver.findElement(By.id("txtEmail")).sendKeys("mukul.agrawal06@gmail.com");
		driver.findElement(By.id("txtAddress")).sendKeys("Chote");
		
		WebElement s = driver.findElement(By.name("City"));
		Select select = new Select(s);
		select.selectByIndex(1);
		select.selectByIndex(2);
		driver.findElement(By.id("txtPhone")).sendKeys("9766331064");
		if (!driver.findElement(By.name("chkHobbies")).isSelected()) {
			driver.findElement(By.cssSelector("input[value='Music']")).click();
			driver.findElement(By.cssSelector("input[value='Reading']")).click();
		}
		
		driver.findElement(By.name("submit")).click();
		
	}
}
