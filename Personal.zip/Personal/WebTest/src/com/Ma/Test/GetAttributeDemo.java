/**
 * 
 */
package com.Ma.Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.gargoylesoftware.htmlunit.javascript.host.media.rtc.webkitRTCPeerConnection;

/**
 * @author mukagraw
 *
 */
public class GetAttributeDemo {

	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.get("http://demo.opencart.com");
		Thread.sleep(10000);
		
		String atValue = driver.findElement(By.xpath("/html/body/div[1]/nav/div[2]/ul/li[1]/a")).getAttribute("href");
		System.out.println("Hyper link of \"Desktops\" is: "+atValue);
		
		driver.get("http://demo.opencart.com/index.php?route=account/register");
		
		Thread.sleep(10000);
		
		WebElement lastname = driver.findElement(By.name("lastname"));
		
		System.out.println("ID: "+lastname.getAttribute("id"));
		System.out.println("Class Name: "+lastname.getAttribute("class"));
		System.out.println("Type: "+lastname.getAttribute("type"));
		System.out.println("Placeholder: "+lastname.getAttribute("placeholder"));
		System.out.println("Value: "+lastname.getAttribute("value"));
		
		Thread.sleep(5000);
		
		lastname.sendKeys("Agrawal");
		
		Thread.sleep(2000);
		
		System.out.println("Updated Value: "+lastname.getAttribute("value"));
		Thread.sleep(5000);
		
		driver.quit();
		
		

	}

}
