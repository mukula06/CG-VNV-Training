/**
 * 
 */
package com.Ma.Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * @author mukagraw
 *
 */
public class GetCommandDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		driver.get("http://demo.opencart.com/");
		System.out.println(driver.getTitle());
		System.out.println(driver.getPageSource());
		System.out.println(driver.getCurrentUrl());
		
		driver.navigate().to("http://demo.opencart.com/");
		driver.navigate().refresh();
		driver.navigate().forward();
		driver.navigate().back();
		driver.close();
	//	driver.quit();
		
	}

}
