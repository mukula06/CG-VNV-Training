/**
 * 
 */
package com.Ma.Test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * @author mukagraw
 *
 */
public class ImplicitandExplicitDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new FirefoxDriver();
		WebDriverWait mywait = new WebDriverWait(driver,30);
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("file:///D:/Module%204/SeleniumSoft/Selenium%20Demos%20&%20Lab%20files/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/WorkingWithForms.html");
		mywait.until(ExpectedConditions.visibilityOfElementLocated(By.id("txtUserName")));
		WebElement t = driver.findElement(By.id("txtUserName"));
		t.sendKeys("Selenium User");

	}

}
