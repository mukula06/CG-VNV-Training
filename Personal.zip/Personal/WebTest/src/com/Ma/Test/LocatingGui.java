/**
 * 
 */
package com.Ma.Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * @author mukagraw
 *
 */
public class LocatingGui {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///D:/Module%204/SeleniumSoft/Lab%20Files/Lab%20Files/EventRegistrationPage.html");

		driver.findElement(By.id("txtFName"));
		driver.findElement(By.className("auto-style2"));
		driver.findElement(By.name("D2"));
		driver.findElement(By
				.linkText("Click here to see complete list of events !!!"));
		driver.findElement(By.partialLinkText("Click here to see"));
		driver.findElement(By.tagName("form"));

	}

}
