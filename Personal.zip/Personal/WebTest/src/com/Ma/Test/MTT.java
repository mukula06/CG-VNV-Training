/**
 * 
 */
package com.Ma.Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * @author mukagraw
 *
 */
public class MTT {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		driver.get("file:///D:/Users/mukagraw/Desktop/123.html");
		System.out.println(driver.findElement(By.cssSelector("#name")).getText());
	}

}
