/**
 * 
 */
package com.Ma.Test;

import java.awt.RenderingHints.Key;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * @author mukagraw
 *
 */
public class SenKeysDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		driver.get("file:///D:/Module%204/SeleniumSoft/Selenium%20Demos%20&%20Lab%20files/Lesson%202%20-%20Demos/Lesson%202%20-%20Demos/HTML%20Pages/LocatingElements.html");

		WebElement t = driver.findElement(By.id("FN"));
		t.sendKeys("Mukul");

		driver.findElement(By.id("LN")).sendKeys("Agrawal");

		// Absolute X-path
		driver.findElement(
				By.xpath("/html/body/form/table/tbody/tr[4]/td[2]/input"))
				.sendKeys("06/09/1994");

		// Relative X-path
		driver.findElement(By.xpath("//*[@id='EmailID']")).sendKeys(
				"mukul.agrawal06@gmail.com");
		driver.findElement(By.xpath("//*[@id='EmailID']")).sendKeys(
				Keys.chord(Keys.CONTROL, "a"));
		driver.findElement(By.xpath("//*[@id='EmailID']")).sendKeys(
				Keys.chord(Keys.CONTROL, "c"));
		driver.findElement(By.id("LN")).clear();
		driver.findElement(By.xpath("//*[@id='LN']")).sendKeys(
				Keys.chord(Keys.CONTROL, "v"));

		// driver.findElement(By.id("LN")).sendKeys(Keys.SPACE);
		// driver.findElement(By.id("FN")).sendKeys(Keys.TAB);

		// driver.close();
	}

}
