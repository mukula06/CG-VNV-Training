/**
 * 
 */
package com.Ma.Test;




import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



/**
 * @author mukagraw
 *
 */
public class TestWeb {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		String baseurl="file:///D:/Module%204/SeleniumSoft/Selenium%20Demos%20&%20Lab%20files/Lesson%202%20-%20Demos/Lesson%202%20-%20Demos/HTML%20Pages/LocatingElements.html";
		String ExpTit = "Employee detail";
		String ActTit = "";
		driver.get(baseurl);
		ActTit=driver.getTitle();
		
		if (ActTit.contentEquals(ExpTit)) {
			System.out.println("Test Pass");
		}
		else {
			System.out.println("Test Failed");
		}
		
		driver.close();
	}

}
