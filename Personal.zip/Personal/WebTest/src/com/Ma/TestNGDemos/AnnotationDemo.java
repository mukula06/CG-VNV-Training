package com.Ma.TestNGDemos;

import org.testng.annotations.Test;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;


public class AnnotationDemo {

	@Test
	public void TC1 () {
		System.out.println("testcase 1 running");
	}
	
	@Test
	public void TC2 () {
		System.out.println("testcase 2 running");
	}
	
	@AfterClass
	public void AC() {
		System.out.println("in After Class");
		// TODO Auto-generated method stub
	}
	
	@BeforeClass
	public void BC() {
		System.out.println("in Before Class");
		// TODO Auto-generated method stub
	}
	
	@AfterMethod
	public void AM() {
		System.out.println("in After Method");
		// TODO Auto-generated method stub
	}
	
	@BeforeMethod
	public void BM() {
		System.out.println("in Before Mathod");
		// TODO Auto-generated method stub
	}
	
	@AfterSuite
	public void AS() {
		System.out.println("in After Suite");
		// TODO Auto-generated method stub
	}
	
	@BeforeSuite
	public void BS() {
		System.out.println("in Before Suite");
		// TODO Auto-generated method stub
	}
	
	@AfterTest
	public void AT() {
		System.out.println("in After Test");
		// TODO Auto-generated method stub
	}
	
	@BeforeTest
	public void BT() {
		System.out.println("in Before Test");
		// TODO Auto-generated method stub
	}
 }
