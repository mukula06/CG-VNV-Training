/**
 * 
 */
package com.Ma.TestNGDemos;

import org.testng.annotations.Test;

/**
 * @author mukagraw
 *
 */
public class PriorityDemo {

	@Test//(priority=3)
	public void Registration() {
		System.out.println("Register Yourself");
	}
	
	@Test(priority=2)
	public void Ailsend() {
		System.out.println("After login mail will be sent");
	}
	
	@Test(priority=1)
	public void Login() {
		System.out.println("After registration login will be done");
	}
}
