package com.Ma.TestNGDemos;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class SoftAssertDemo {
	WebDriver driver;
	SoftAssert softassert = new SoftAssert();

	@BeforeTest
	public void openBrowser() {
		driver = new FirefoxDriver();
		driver.get("http://demo.opencart.com/");
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		
		Assert.assertEquals(driver.getTitle(), "The OpenCart demo store");
	}
	
	@Test
	public void testcaseone() throws InterruptedException {
		softassert.assertTrue(false);
		WebElement searchBox = driver.findElement(By.name("search"));
		searchBox.sendKeys("Phone");
		Thread.sleep(5000);
		
		driver.findElement(By.className("input-group-btn")).click();
		Thread.sleep(5000);
		
		softassert.assertEquals(driver.getTitle(), "Search - Phone","Phone search failed");
		driver.findElement(By.id("input-search")).clear();
		driver.findElement(By.id("input-search")).sendKeys("mac");
		Thread.sleep(5000);
		driver.findElement(By.id("button-search")).click();
		Thread.sleep(5000);
		softassert.assertEquals(driver.getTitle(), "Search - mac","Mac search failed");
		
		Thread.sleep(5000);
		softassert.assertAll();
		
	}
	
	@AfterTest
	public void closeBrpw() {
		driver.quit();
	}
}
