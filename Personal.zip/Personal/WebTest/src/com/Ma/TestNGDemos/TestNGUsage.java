/**
 * 
 */
package com.Ma.TestNGDemos;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author mukagraw
 *
 */
public class TestNGUsage {

	String message = "Hello World";
	testng t = new testng(message);
	
	@Test
	public void testPrintMessage() {
		// TODO Auto-generated method stub
		Assert.assertEquals(message,t.printMessage());

	}
}
