/**
 * 
 */
package com.Ma.TestNGDemos;


/**
 * @author mukagraw
 *
 */
public class testng {

	private String message;

	public testng(String message) {
		this.message = message;
	}
	
	public String printMessage() {
		System.out.println(message);
		return message;
	}
}
