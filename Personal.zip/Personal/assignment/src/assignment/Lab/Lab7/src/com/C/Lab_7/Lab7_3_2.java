/**
 * 
 */
package com.C.Lab_7;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


/**
 * @author mukagraw
 *
 */
public class Lab7_3_2 {
	WebDriver driver;

	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "D:\\Module 4\\Drivers\\New_Chrome_Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//System.setProperty("webdriver.ie.driver", "D:\\Module 4\\Drivers\\New IE driver\\IEDriverServer.exe");
		//WebDriver driver = new InternetExplorerDriver();
		
		String baseurl="http://demo.opencart.com/index.php?route=account/register";
		driver.get(baseurl);
		
		lab3_2_1 Ch = new lab3_2_1();
		System.out.println("First Name test:");
		lab3_2_2 ch1 = new lab3_2_2();
		Ch.checkFirstName();
		System.out.println();
		System.out.println("Last Name test:");
		ch1.checkLastName();
		System.out.println();
		Lab3_2_3 PM = new Lab3_2_3();
		PM.chkPhnEmail();

		Thread.sleep(5000);
		driver.quit();
	}

}

class lab3_2_1 extends Lab7_3_2 {
	
	public void checkFirstName () {
		
		int count=0;
		
		driver.findElement(By.id("input-firstname")).sendKeys("");
		driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
		String expErrFrstNam = "First Name must be between 1 and 32 characters!";
		String actErrFrstNam = "";
		WebElement e = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/form/fieldset[1]/div[2]/div/div"));
		actErrFrstNam = e.getText();
		if (actErrFrstNam.contentEquals(expErrFrstNam)) {
			System.out.println("Number of characters when error is showing: 0");
			count++;
		}
		
		driver.findElement(By.id("input-firstname")).sendKeys("Mmmmm");
		driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
		Alert alert=driver.switchTo().alert();
		alert.accept();
		System.out.println("No error when no of character is: 5");
			
		driver.findElement(By.id("input-firstname")).sendKeys("Mmmmmmmmmmmmmmmmmmmmmmmmmmmm");
		driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
		alert.accept();
		
		expErrFrstNam = "First Name must be between 1 and 32 characters!";
		actErrFrstNam = "";
		e = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/form/fieldset[1]/div[2]/div/div"));
		actErrFrstNam = e.getText();
		if (actErrFrstNam.contentEquals(expErrFrstNam)) {
			System.out.println("Number of characters when error is showing: 33");
			count++;
		}
	
		if (count>0)
			System.out.println("Error message for first name is varified");
	}
	
}

class lab3_2_2 extends Lab7_3_2 {
	
	public void checkLastName () {
		
		int count=0;
		
		driver.findElement(By.id("input-lastname")).sendKeys("");
		driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
		Alert alert=driver.switchTo().alert();
		alert.accept();
		String expErrLstNam = "Last Name must be between 1 and 32 characters!";
		String actErrLstNam = "";
		WebElement e = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/form/fieldset[1]/div[3]/div/div"));
		actErrLstNam = e.getText();
		if (actErrLstNam.contentEquals(expErrLstNam)) {
			System.out.println("Number of characters when error is showing: 0");
			count++;
		}
		
		driver.findElement(By.id("input-lastname")).sendKeys("Mmmmm");
		driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
		
		alert.accept();
		System.out.println("No error when no of character is: 5");
			
		driver.findElement(By.id("input-lastname")).sendKeys("Mmmmmmmmmmmmmmmmmmmmmmmmmmmm");
		driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
		alert.accept();
		expErrLstNam = "Last Name must be between 1 and 32 characters!";
		actErrLstNam = "";
		e = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/form/fieldset[1]/div[3]/div/div"));
		actErrLstNam = e.getText();
		if (actErrLstNam.contentEquals(expErrLstNam)) {
			System.out.println("Number of characters when error is showing: 33");
			count++;
		}
	
		if (count>0)
			System.out.println("Error message for Last name is varified");
	}
	
}

class DataValidator {
	
	public boolean Datavalidate(String pattern,String str)
	{
		Pattern pat=Pattern.compile(pattern);
		Matcher matcher=pat.matcher(str);
		return matcher.matches();
		
	}
}

class Lab3_2_3 extends Lab7_3_2 

{
	public void chkPhnEmail () {
		String PhonePattern = "[0-9]{3,32}";
		String EmailPattern = "\\b[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b";
		
		String PhoneNo = "91";
		String EmailId = "mukul.agrawal06gmail.com";
		
		DataValidator DV = new DataValidator();
		
		boolean Phon = DV.Datavalidate(PhonePattern, PhoneNo);
		boolean Email = DV.Datavalidate(EmailPattern, EmailId);
		
		
		
		if (Phon == true && Email == true) 
		{
			driver.findElement(By.id("input-telephone")).sendKeys(PhoneNo);
			driver.findElement(By.id("input-email")).sendKeys(EmailId);
			System.out.println("Entered correct Mail id and Phone no.");
		}
		else if (Phon == true && Email == false)
		{
			driver.findElement(By.id("input-telephone")).sendKeys(PhoneNo);
			System.out.println("Entered correct Phone no.");
			System.out.println("Wrong Mail Id.");
		}
		else if (Phon == false && Email == true)
		{
			driver.findElement(By.id("input-email")).sendKeys(EmailId);
			System.out.println("Entered correct Mail id.");
			System.out.println("Wrong Phone No.");
		}
		else
			System.out.println("Wrong Mobile no and Email Id.");
		
		driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
		Alert alert=driver.switchTo().alert();
		alert.accept();
	}
}
