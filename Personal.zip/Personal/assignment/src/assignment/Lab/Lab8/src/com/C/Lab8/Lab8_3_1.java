/**
 * 
 */
package com.C.Lab8;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 * @author mukagraw
 *
 */
public class Lab8_3_1 {

	/**
	 * @param args
	 * @throws MalformedURLException 
	 */
	public static void main(String[] args) throws MalformedURLException {
		// TODO Auto-generated method stub

		
		/*String nodeurl = "http://10.102.54.28:5666/wd/hub";
		DesiredCapabilities DC = new DesiredCapabilities().firefox();
		DC.setBrowserName("firefox");
		DC.setPlatform(Platform.WINDOWS);
		WebDriver driver = new RemoteWebDriver(new URL(nodeurl), DC);*/
		
		WebDriver driver = new RemoteWebDriver(new URL("http://10.102.54.28:5666/wd/hub"),DesiredCapabilities.internetExplorer());
		
		
		/*System.setProperty("webdriver.chrome.driver", "D:\\Module 4\\Drivers\\New_Chrome_Driver\\chromedriver.exe");
		String nodeurl = "http://10.102.54.28:5666/wd/hub";
		DesiredCapabilities DC = new DesiredCapabilities().chrome();
		DC.setBrowserName("chrome");
		DC.setPlatform(Platform.WINDOWS);
		WebDriver driver = new RemoteWebDriver(new URL(nodeurl), DC);*/
		
		String baseurl="http://demo.opencart.com/";
		String ExpTit = "The OpenCart demo store";
		String ActTit = "";
		String RegExpHead = "Register Account";
		String RegActHead = "";
		String WarExpHead = "Warning: You must agree to the Privacy Policy!";
		String WarActHead = "";
		driver.get(baseurl);
		ActTit=driver.getTitle();
		if (ActTit.contentEquals(ExpTit)) {
			System.out.println("Title Verified");
		}
		else {
			System.out.println("Title not verified");
		}
		
		driver.findElement(By.className("caret")).click();
		driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul/li[2]/ul/li[1]/a")).click();
		
		
		WebElement e = driver.findElement(By.xpath("/html/body/div[2]/div/div/h1")); /*driver.getTitle();*/
		RegActHead = e.getText();
		
		//System.out.println(RegActHead);
		
		if (RegActHead.contentEquals(RegExpHead)) {
			System.out.println("Register heading Verified");
		}
		else {
			System.out.println("Register heading not verified");
		}
		
		//driver.findElement(By.xpath("/html/body/div[2]/div/div/form/div/div/input[2]")).click();
		driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
		//driver.findElement(By.className("btn btn-primary")).click();
		

		Alert alert=driver.switchTo().alert();
		//System.out.println(alert.getText());
		alert.accept();
		
		WebElement e1 = driver.findElement(By.xpath("/html/body/div[2]/div[1]")); /*driver.getTitle();*/
		WarActHead = e1.getText();
		
		if (WarActHead.contentEquals(WarExpHead)) {
			System.out.println("Warning is Verified");
		}
		else {
			System.out.println("Warning is not verified");
		}
	}

}
