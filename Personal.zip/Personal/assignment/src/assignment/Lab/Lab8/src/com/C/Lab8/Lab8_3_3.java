/**
 * 
 */
package com.C.Lab8;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;





/**
 * @author mukagraw
 *
 */
public class Lab8_3_3 {

	static WebDriver driver;
	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		String baseurl="http://demo.opencart.com/index.php?route=account/register";
		driver.get(baseurl);
		Lab3_3_1 ACP = new Lab3_3_1();
		Lab3_3_2 Passw = new Lab3_3_2();
		driver.findElement(By.id("input-firstname")).sendKeys("Mukul");
		driver.findElement(By.id("input-lastname")).sendKeys("Agrawal");
		driver.findElement(By.id("input-email")).sendKeys("mukul.agrawal0006@gmail.com");
		driver.findElement(By.id("input-telephone")).sendKeys("97663106");
		ACP.chkAddCitPin();
		
		WebElement Country = driver.findElement(By.id("input-country"));
		Select select1 = new Select(Country);
		select1.selectByValue("99");
		
		Thread.sleep(4000);
		
		WebElement State = driver.findElement(By.id("input-zone"));
		Select select2 = new Select(State);
		select2.selectByValue("1501");
		
		Passw.chkPass();
		
		driver.findElement(By.xpath("/html/body/div[2]/div/div/form/fieldset[4]/div/div/label[1]/input")).click();
		
		if (!driver.findElement(By.name("agree")).isSelected()) {
			driver.findElement(By.xpath("/html/body/div[2]/div/div/form/div/div/input[1]")).click();
		}
		
		driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
		//Alert alert=driver.switchTo().alert();
		//alert.accept();
		String ActTit="";
		String ExpTit = "Your Account Has Been Created!";
		
		WebElement Head = driver.findElement(By.xpath("/html/body/div[2]/div/div/h1"));
		ActTit = Head.getText();
		
		if (ActTit.contentEquals(ExpTit)) {
			System.out.println("Message is Verified");
		}
		else {
			System.out.println("Message is not verified");
		}
		
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/a")).click();
		
		driver.findElement(By.xpath("/html/body/div[2]/div/div/ul[2]/li[1]/a")).click();
		
	}

}


class DataValidate {
	
	public boolean Datavalidate(String pattern,String str)
	{
		Pattern pat=Pattern.compile(pattern);
		Matcher matcher=pat.matcher(str);
		return matcher.matches();
		
	}
}

class Lab3_3_1 extends Lab8_3_3 

{
	public void chkAddCitPin () {
		String Add1Pattern = "[A-Z a-z0-9./_]{3,128}";
		String CityPattern = "[A-Za-z]{2,128}";
		String PinCodePatt = "[0-9]{2,10}";
		
		String Address = "M.B. Metals";
		String City = "Udaipur";
		String PinCode = "313803";
		
		DataValidate DV = new DataValidate();
		
		boolean Add1 = DV.Datavalidate(Add1Pattern, Address);
		boolean Cit = DV.Datavalidate(CityPattern, City);
		boolean PinCd = DV.Datavalidate(PinCodePatt, PinCode);
		
		
		
		
		if (Add1 == true) {
			if (Cit == true) {
				if (PinCd == true) {
					driver.findElement(By.id("input-address-1")).sendKeys(Address);
					driver.findElement(By.id("input-city")).sendKeys(City);
					driver.findElement(By.id("input-postcode")).sendKeys(PinCode);
					System.out.println("Entered Address, City and Postcode are in correct format.");
				}
				else
					System.out.println("Postcode is wrong.");
			}
			else
				System.out.println("either City or Postcode is wrong.");
		}
		else
			System.out.println("either Address or City or Postcode is wrong.");
		
		
	}
}

class Lab3_3_2 extends Lab8_3_3

{
	public void chkPass () {
		String PasswordPattern = "[A-Za-z0-9]{4,20}";
		
		String Password = "Mukul123";
		
		DataValidate DV = new DataValidate();
		
		boolean Pass = DV.Datavalidate(PasswordPattern, Password);
		
		if (Pass == true) {
			driver.findElement(By.id("input-password")).sendKeys(Password);
			driver.findElement(By.id("input-confirm")).sendKeys(Password);
			System.out.println("Password in Entered");
		}
		else
			System.out.println("Password in wrong Pattern");
		
	}
}

