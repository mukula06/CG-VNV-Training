/**
 * 
 */
package com.C.Lab8;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

/**
 * @author mukagraw
 *
 */
public class Lab8_4_1 {

	/**
	 * @param args
	 * @throws InterruptedException 
	 * @throws MalformedURLException 
	 */
	public static void main(String[] args) throws InterruptedException, MalformedURLException {
		// TODO Auto-generated method stub

		/*String nodeurl = "http://10.102.54.28:5666/wd/hub";
		DesiredCapabilities DC = new DesiredCapabilities().firefox();
		DC.setBrowserName("firefox");
		DC.setPlatform(Platform.WINDOWS);
		WebDriver driver = new RemoteWebDriver(new URL(nodeurl), DC);*/
		
		WebDriver driver = new RemoteWebDriver(new URL("http://10.102.54.28:5666/wd/hub"),DesiredCapabilities.internetExplorer());
		
		
		/*System.setProperty("webdriver.chrome.driver", "D:\\Module 4\\Drivers\\New_Chrome_Driver\\chromedriver.exe");
		String nodeurl = "http://10.102.54.28:5666/wd/hub";
		DesiredCapabilities DC = new DesiredCapabilities().chrome();
		DC.setBrowserName("chrome");
		DC.setPlatform(Platform.WINDOWS);
		WebDriver driver = new RemoteWebDriver(new URL(nodeurl), DC);*/
		
		
		driver.get("http://demo.opencart.com/index.php?route=account/login");
		
		driver.findElement(By.id("input-email")).sendKeys("mukul.agrawal06@gmail.com");
		driver.findElement(By.id("input-password")).sendKeys("Mukul123");
		//click on Login
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div/form/input")).click();
		//click on component
		driver.findElement(By.xpath("/html/body/div[1]/nav/div[2]/ul/li[3]/a")).click();
		//click on monitor
		driver.findElement(By.xpath("/html/body/div[1]/nav/div[2]/ul/li[3]/div/div/ul/li[2]/a")).click();

		//Select 25 from drop down box
		WebElement webelementShow = driver.findElement(By.id("input-limit"));
		Select selectShow = new Select(webelementShow);
		selectShow.selectByVisibleText("25");
		
		//click on add to cart for first item
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div[3]/div[1]/div/div[2]/div[2]/button[1]")).click();
		Thread.sleep(2000);
		//click on specification tab
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/div[1]/ul[2]/li[2]/a")).click();
		
		String expFeaturePro = "Clockspeed";
		String ActFeaturePro = driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/div[1]/div/div[2]/table/tbody/tr/td[1]")).getText();
		String expFeature = "100mhz";
		String ActFeature = driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/div[1]/div/div[2]/table/tbody/tr/td[2]")).getText();
		
		if (ActFeaturePro.contentEquals(expFeaturePro)) {
			System.out.print("Specification Title varified\t");
		}
		else
			System.out.print("\nSpecification title not varified\t");
		
		if (ActFeature.contentEquals(expFeature)) {
			System.out.print("\tSpecification varified\n");
		}
		else
			System.out.print("\tSpecification not varified\n");
		
		//Click on 'Add to Wish list' button.
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/div[2]/div[1]/button[1]")).click();
		
		Thread.sleep(2000);
		
		//Verify message 'Success: You have added Apple Cinema 30" to your wish list!'
		System.out.println("Actual Message: "+driver.findElement(By.xpath("/html/body/div[2]/div[1]")).getText().substring(0, 46));
		System.out.println("Expected Message: Apple Cinema 30\" is already in your wish list!");
		
		if (driver.findElement(By.xpath("/html/body/div[2]/div[1]")).getText().substring(0, 46).contentEquals("Apple Cinema 30\" is already in your wish list!")) {
			System.out.println("Add Wish list message verified");
		}
		else
			System.out.println("Add Wish list message not verified");
		
		Thread.sleep(1000);
		
		
		//Enter Mobile in search box
		driver.findElement(By.xpath("/html/body/header/div/div/div[2]/div/input")).sendKeys("Mobile");
		//Click on search button
		driver.findElement(By.xpath("/html/body/header/div/div/div[2]/div/span/button")).click();
		
		//Select the check box
		if (!driver.findElement(By.name("description")).isSelected()) {
			driver.findElement(By.name("description")).click();
		}
		
		//Click on search
		driver.findElement(By.xpath("/html/body/div[2]/div/div/input")).click();
		Thread.sleep(2000);
		//Click on link 'HTC Touch HD' for the mobile 'HTC Touch HD'
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div[4]/div[1]/div/div[2]/h4/a")).click();
		//Clear '1' from 'Qty' and enter '3'
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div[2]/div/input[1]")).clear();
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div[2]/div/input[1]")).sendKeys("3");
		
		//Click on 'Add to Cart' button
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div[2]/div/button")).click();
		Thread.sleep(3000);
		//Verify success message 'Success: You have added HTC Touch HD to your shopping cart!'
		String ExpMess = "Success: You have added HTC Touch HD to your shopping cart!";
		Thread.sleep(500);
		String ActMess = new String(driver.findElement(By.xpath("/html/body/div[2]/div[1]")).getText());
		
		System.out.println(ExpMess);
		System.out.println(ActMess.substring(0, 59));
		if (ActMess.substring(0, 59).contentEquals(ExpMess)) {
			System.out.println("Success Message is varified");
		}
		else
			System.out.println("Success Message not varified");
		
		//Click on 'View cart' button adjacent to search button
		driver.findElement(By.xpath("/html/body/header/div/div/div[3]/div/button")).click();
		//Verify Mobile name added to the cart
		String ExpViewMble = "HTC Touch HD";
		String ActViewMble = driver.findElement(By.xpath("/html/body/header/div/div/div[3]/div/ul/li[1]/table/tbody/tr/td[2]/a")).getText();
		if (ActViewMble.contentEquals(ExpViewMble)) {
			System.out.println("Added item heading is varified");
		}
		else
			System.out.println("Added item heading is not varified");
		
		//Click on 'Checkout' button
		driver.findElement(By.xpath("/html/body/header/div/div/div[3]/div/ul/li[2]/div/p/a[2]/strong/i")).click();
		
		//Click on My Account
		driver.findElement(By.className("caret")).click();
		Thread.sleep(3000);
		//Click on logout
		driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul/li[2]/ul/li[5]/a")).click();
		//Verify Logout heading
		if (driver.findElement(By.tagName("h1")).getText().contentEquals("Account Logout")) {
			System.out.println("Logout heading is varified");
		}
		else
			System.out.println("Logout heading is not varified");
		//click on continue
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/a")).click();
		
		Thread.sleep(4000);
		driver.quit();
	}

}
