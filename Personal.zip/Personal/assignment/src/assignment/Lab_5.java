/**
 * 
 */
package assignment;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

/**
 * @author nbobde
 *
 */
public class Lab_5 {

	static WebDriver driver= new FirefoxDriver();
	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		//String baseurl="http://demo.opencart.com/";
	
		driver.get("https://ispace.ig.capgemini.com/sitepages/index.aspx");
		
		
		Thread.sleep(5000);
		
		
		driver.findElement(By.xpath("/html/body/form/div[13]/div/div[2]/div[2]/header/nav[1]/div/div[2]/div/ul/li/ul/li[2]/a/span/span")).click();
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("/html/body/form/div[20]/div/div[2]/div[2]/div[2]/div/div[1]/article/content/div/div[2]/div/div/div[1]/div[2]/div[1]/p[6]/input")).click();
		
		Thread.sleep(5000);
		
		//Verify the new title �Stationary�
		
		String ExpTit = "Stationary";
		String ActTit = "";
		String RegExpHead = "Register Account";
		String RegActHead = "";

		ActTit=driver.getTitle();
		if (ActTit.contentEquals(ExpTit)) {
			System.out.println("Title Verified");
		}
		else {
			System.out.println("Title not verified");
		}
		
		
		
		//On �Stationery� tab, click on 'Submit to collect your Stationery >>>' link
		
		
		
	}

}
