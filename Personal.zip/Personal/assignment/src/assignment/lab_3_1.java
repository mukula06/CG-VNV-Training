/**
 * 
 */
package assignment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


/**
 * @author nbobde
 *
 */
public class lab_3_1 {
	
	public static void main(String[] args){
		// TODO Auto-generated method stub
		
	
		WebDriver driver = new FirefoxDriver();
		driver.get("http://demo.opencart.com/");
	
		String ExpTit = "The OpenCart demo store";
		String ActTit = "";
		String RegExpHead = "Register Account";
		String RegActHead = "";
		String WarExpHead = "Warning: You must agree to the Privacy Policy!";
		String WarActHead = "";
		ActTit=driver.getTitle();
		if (ActTit.contentEquals(ExpTit)) {
			System.out.println("Title Verified");
		}
		else {
			System.out.println("Title not verified");
		}
		
		driver.findElement(By.className("caret")).click();
		driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul/li[2]/ul/li[1]/a")).click();
		
		
		WebElement e = driver.findElement(By.xpath("/html/body/div[2]/div/div/h1")); /*driver.getTitle();*/
		RegActHead = e.getText();
		
		//System.out.println(RegActHead);
		
		if (RegActHead.contentEquals(RegExpHead)) {
			System.out.println("Register heading Verified");
		}
		else {
			System.out.println("Register heading not verified");
		}
		
		//driver.findElement(By.xpath("/html/body/div[2]/div/div/form/div/div/input[2]")).click();
		driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
		//driver.findElement(By.className("btn btn-primary")).click();
		

		Alert alert=driver.switchTo().alert();
		//System.out.println(alert.getText());
		alert.accept();
		
		WebElement e1 = driver.findElement(By.xpath("/html/body/div[2]/div[1]")); /*driver.getTitle();*/
		WarActHead = e1.getText();
		
		if (WarActHead.contentEquals(WarExpHead)) {
			System.out.println("Warning is Verified");
		}
		else {
			System.out.println("Warning is not verified");
		}

	}

}

