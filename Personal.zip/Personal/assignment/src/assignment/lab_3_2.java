/**
 * 
 */
package assignment;

import org.apache.xalan.xsltc.compiler.Pattern;
import org.hamcrest.Matcher;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.Keys;


/**
 * @author nbobde
 *
 */
public class lab_3_2 {
	
static WebDriver driver = new FirefoxDriver();
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String baseurl="http://demo.opencart.com/index.php?route=account/register";
		driver.get(baseurl);
		
		lab_3_1_2_1 Ch = new lab_3_1_2_1();
		System.out.println("First Name test:");
		lab_3_1_2_2 ch1 = new lab_3_1_2_2();
		Ch.checkFirstName();
		System.out.println("");
		System.out.println("Last Name test:");
		ch1.checkLastName();
	
		Lab_3_2_3 Ch2 = new Lab_3_2_3();
		Ch2.checkTelephone();
		System.out.println("Telephone test:");
		
	}

}




class lab_3_1_2_1 extends lab_3_2 {
	
	public void checkFirstName () {
		
		int count=0;
		
		driver.findElement(By.id("input-firstname")).sendKeys("");
		driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
		String expErrFrstNam = "First Name must be between 1 and 32 characters!";
		String actErrFrstNam = "";
		WebElement e = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/form/fieldset[1]/div[2]/div/div"));
		actErrFrstNam = e.getText();
		if (actErrFrstNam.contentEquals(expErrFrstNam)) {
			System.out.println("Number of characters when error is showing: 0");
			count++;
		}
		
		driver.findElement(By.id("input-firstname")).sendKeys("Nilesh");
		driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
		Alert alert=driver.switchTo().alert();
		alert.accept();
		System.out.println("No error when no of character is: 6");
			
		driver.findElement(By.id("input-firstname")).sendKeys("nnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
		driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
		alert.accept();
		
		expErrFrstNam = "First Name must be between 1 and 32 characters!";
		actErrFrstNam = "";
		e = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/form/fieldset[1]/div[2]/div/div"));
		actErrFrstNam = e.getText();
		if (actErrFrstNam.contentEquals(expErrFrstNam)) {
			System.out.println("Number of characters when error is showing: 33");
			count++;
		}
	
		if (count>0)
			System.out.println("Error message for first name is varified");
	}
	
}

class lab_3_1_2_2 extends lab_3_2 {
	
	public void checkLastName () {
		
		int count=0;
		
		driver.findElement(By.id("input-lastname")).sendKeys("");
		driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
		Alert alert=driver.switchTo().alert();
		alert.accept();
		String expErrLstNam = "Last Name must be between 1 and 32 characters!";
		String actErrLstNam = "";
		WebElement e = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/form/fieldset[1]/div[3]/div/div"));
		actErrLstNam = e.getText();
		if (actErrLstNam.contentEquals(expErrLstNam)) {
			System.out.println("Number of characters when error is showing: 0");
			count++;
		}
		
		driver.findElement(By.id("input-lastname")).sendKeys("Bobde");
		driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
		
		alert.accept();
		System.out.println("No error when no of character is: 5");
			
		driver.findElement(By.id("input-lastname")).sendKeys("bbbbbbbbbbbbbbbbbbbbbbbbbbbbbb");
		driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
		alert.accept();
		expErrLstNam = "Last Name must be between 1 and 32 characters!";
		actErrLstNam = "";
		e = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/form/fieldset[1]/div[3]/div/div"));
		actErrLstNam = e.getText();
		if (actErrLstNam.contentEquals(expErrLstNam)) {
			System.out.println("Number of characters when error is showing: 33");
			count++;
		}
	
		if (count>0)
			System.out.println("Error message for Last name is varified");
		
		
		//Email Validation
		System.out.println("Enter the Valid Email Id");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.findElement(By.cssSelector("input[type='email'][value='']")).sendKeys("NileshBobde@gmail.com");
		Object s=js.executeScript("return document.getElementById(\"input-email\").validity.valid");
		System.out.println(s);	
		
		
		//Phone number Validation
		
		
	}
	
	
	
}

class DataValidator {
	
	public boolean Datavalidate(String pattern,String str)
	{
		Pattern pat=Pattern.compile(pattern);
		Matcher matcher=pat.matcher(str);
		return matcher.matches();
		
	}
}




class Lab_3_2_3 extends lab_3_2 {
	public void checkTelephone () {

	String PhonePattern = "[0-9]{3,32}";
	//String EmailPattern = "\\b[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b";
	
	String PhoneNo = "91";
	//String EmailId = "mukul.agrawal06gmail.com";
	
	DataValidator DV = new DataValidator();
	
	boolean Phon = DV.Datavalidate(PhonePattern, PhoneNo);
	//boolean Email = DV.Datavalidate(EmailPattern, EmailId);
	
	
	
	if (Phon == true ) 
	{
		driver.findElement(By.id("input-telephone")).sendKeys(PhoneNo);
		//driver.findElement(By.id("input-email")).sendKeys(EmailId);
		System.out.println("Entered correct Mail id and Phone no.");
	}
	/*//else if (Phon == true && Email == false)
	{
		driver.findElement(By.id("input-telephone")).sendKeys(PhoneNo);
		System.out.println("Entered correct Phone no.");
		System.out.println("Wrong Mail Id.");
	}
	//else if (Phon == false && Email == true)
	{
		driver.findElement(By.id("input-email")).sendKeys(EmailId);
		System.out.println("Entered correct Mail id.");
		System.out.println("Wrong Phone No.");
	}*/
	else
		System.out.println("Wrong Mobile no and Email Id.");
	
	driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
	Alert alert=driver.switchTo().alert();
	alert.accept();
	}
}


