/**
 * 
 */
package assignment;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



/**
 * @author nbobde
 *
 */
public class lab_4_1 {
	
	static WebDriver driver= new FirefoxDriver();
	
	public static void main(String[] args) throws InterruptedException {
	
		
	//String baseurl="http://demo.opencart.com/";
	driver.get("http://demo.opencart.com/index.php?route=account/login");
	
	
	Thread.sleep(2000);
	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	// Enter UserName
	driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div/form/div[1]/input")).sendKeys("nileshbobde131091@gmail.com");
	
	
	Thread.sleep(2000);
	
	// Enter Password
	driver.findElement(By.id("input-password")).sendKeys("nilesh123456");
	
	Thread.sleep(2000);
	
	
	//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	
	// Click on 'Sign In' button
	driver.findElement(By.xpath("html/body/div[2]/div/div/div/div[2]/div/form/input")).click();
	
	
	// Wait For Page To Load
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	
	Thread.sleep(2000);
	//Click on to the Component Dropdown
	
	driver.findElement(By.xpath("/html/body/div[1]/nav/div[2]/ul/li[3]/a")).click();
	driver.findElement(By.xpath("/html/body/div[1]/nav/div[2]/ul/li[3]/div/div/ul/li[2]/a"));
	
	
	Thread.sleep(2000);
	
	//select 25 drop the drop down
	driver.findElement(By.xpath("/html/body/div[1]/nav/div[2]/ul/li[3]/div/div/ul/li[2]/a")).click();
	driver.findElement(By.xpath("/html/body/div[2]/div/div/div[2]/div[5]/select/option[2]")).click();
	
	Thread.sleep(2000);

	
	//Click add to cart
	
	driver.findElement(By.xpath("/html/body/div[2]/div/div/div[3]/div[1]/div/div[2]/div[2]/button[1]")).click();
	
	
	Thread.sleep(2000);
	//Click on 'Specification' tab
	
	driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/div[1]/ul[2]/li[2]/a")).click();
	
	
	Thread.sleep(2000);
	//Verified the data on the page
	
	
	String expFeaturePro = "Clockspeed";
	String ActFeaturePro = driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/div[1]/div/div[2]/table/tbody/tr/td[1]")).getText();
	String expFeature = "100mhz";
	String ActFeature = driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/div[1]/div/div[2]/table/tbody/tr/td[2]")).getText();
	
	if (ActFeaturePro.contentEquals(expFeaturePro)) {
		System.out.print("Specification Title varified\t");
	}
	else
		System.out.print("\nSpecification title not varified\t");
	
	if (ActFeature.contentEquals(expFeature)) {
		System.out.print("\tSpecification varified\n");
	}
	else
		System.out.print("\tSpecification not varified\n");
	
	//Click on 'Add to Wish list' button.
	
	driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/div[2]/div[1]/button[1]")).click();
	
	Thread.sleep(2000);
	
	//Verify message 'Success: You have added Apple Cinema 30" to your wish list!'
	
	String expAppleCenema = "Success: You have added Apple Cinema 30";
	String ActAppleCenema = driver.findElement(By.xpath("/html/body/div[2]/ul/li[2]/a")).getText();
		
	if (ActFeaturePro.contentEquals(expFeaturePro)) {
		System.out.print("varified\t");
	}
	else
		System.out.print("\n not varified\t");
	
	if (ActFeature.contentEquals(expFeature)) {
		System.out.print("\t Apple Cinema 30 varified\n");
	}
	else
		System.out.print("\t Apple Cinema 30 not varified\n");
	
	
	
	
	//Enter 'Mobile' in ' Search' text box.
	driver.findElement(By.xpath("/html/body/header/div/div/div[2]/div/input")).sendKeys("Mobile");
	
	Thread.sleep(2000);
	
	driver.findElement(By.xpath("/html/body/header/div/div/div[2]/div/span/button")).click();

	Thread.sleep(2000);
	
	//Click on 'Search in product descriptions' check box
	
	driver.findElement(By.id("description")).click();
	Thread.sleep(2000);
	driver.findElement(By.id("button-search")).click();
	Thread.sleep(2000);
	
	//Click on link 'HTC Touch HD' for the mobile 'HTC Touch HD'
	driver.findElement(By.xpath("/html/body/div[2]/div/div/div[4]/div[1]/div/div[2]/h4/a")).click();
	Thread.sleep(2000);
	
	
	//Clear '1' from 'Qty' and enter '3'
	driver.findElement(By.id("input-quantity")).clear();
	driver.findElement(By.id("input-quantity")).sendKeys("3");
	Thread.sleep(2000);
	
	
	//Click on 'Add to Cart' button
	driver.findElement(By.id("button-cart")).click();
	
	//Verify success message 'Success: You have added HTC Touch HD to your shopping cart!'
	Thread.sleep(2000);
	
	String ExpMess = "Success: You have added HTC Touch HD to your shopping cart!";
	Thread.sleep(500);
	String ActMess = new String(driver.findElement(By.xpath("/html/body/div[2]/div[1]")).getText());
	
	System.out.println(ExpMess);
	System.out.println(ActMess.substring(0, 59));
	if (ActMess.substring(0, 59).contentEquals(ExpMess)) {
		System.out.println("Success Message is varified");
	}
	else
		System.out.println("Success Message not varified");
	
	
	//Click on 'View cart' button 
	driver.findElement(By.xpath("/html/body/header/div/div/div[3]/div/button")).click();
	Thread.sleep(2000);
	
	//Verify Mobile name added to the cart
	
	String ExpViewMble = "HTC Touch HD";
	String ActViewMble = driver.findElement(By.xpath("/html/body/header/div/div/div[3]/div/ul/li[1]/table/tbody/tr/td[2]/a")).getText();
	if (ActViewMble.contentEquals(ExpViewMble)) {
		System.out.println("Added item heading is varified");
	}
	else
		System.out.println("Added item heading is not varified");
	
	
	//Click on 'Checkout' button
		
	driver.findElement(By.xpath("/html/body/header/div/div/div[3]/div/ul/li[2]/div/p/a[2]/strong/i")).click();
	Thread.sleep(2000);
	
	
	//Click on 'My Account' dropdown
	
	//driver.findElement(By.className("caret")).click();
	driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul/li[2]/a")).click();
	Thread.sleep(2000);
	
	
	//Select 'Logout' from dropdown
	
	driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul/li[2]/ul/li[5]/a")).click();
	
	Thread.sleep(2000);
	
	
	//Verify 'Account Logout' heading
	
	if ((driver.findElement(By.xpath("/html/body/div[2]/div/div/h1")).getText()).contentEquals("Account Logout")) {
		System.out.println("Logout heading is varified");
	}
	else
		System.out.println("Logout heading is not varified");
	
	
	Thread.sleep(2000);
	//Click on 'Continue'
	
	driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/a")).click();
	Thread.sleep(2000);
	
	
	driver.quit();
	
	}
	

}
