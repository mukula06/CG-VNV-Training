/**
 * 
 */
package assignment;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

/**
 * @author nbobde
 *
 */
public class lab_6_1 {
	WebDriver driver = new FirefoxDriver();
	@Before
	public void openBrowser() throws InterruptedException
	{
		
		driver.get("http://demo.opencart.com/");
		Thread.sleep(2000);
		driver.findElement(By.className("caret")).click();
		driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul/li[2]/ul/li[1]/a")).click();
		
		driver.findElement(By.id("input-firstname")).sendKeys("Nilesh");
		driver.findElement(By.id("input-lastname")).sendKeys("Bobde");
		driver.findElement(By.id("input-email")).sendKeys("ramvan@gmail.com");
		driver.findElement(By.id("input-telephone")).sendKeys("8007410433");
		
		driver.findElement(By.id("input-address-1")).sendKeys("Kalmeshwar");
		driver.findElement(By.id("input-city")).sendKeys("Nagpur");
		driver.findElement(By.id("input-postcode")).sendKeys("441501");
		
		WebElement Country = driver.findElement(By.id("input-country"));
		Select select1 = new Select(Country);
		select1.selectByValue("99");
		
		Thread.sleep(2000);
		
		WebElement State = driver.findElement(By.id("input-zone"));
		Select select2 = new Select(State);
		select2.selectByValue("1493");
		
		driver.findElement(By.id("input-password")).sendKeys("ram8007410433");
		driver.findElement(By.id("input-confirm")).sendKeys("ram8007410433");
		
		driver.findElement(By.xpath("/html/body/div[2]/div/div/form/fieldset[4]/div/div/label[1]/input")).click();
	}

	@Test
	public void Test()
	{
		
		if (!driver.findElement(By.name("agree")).isSelected()) {
			driver.findElement(By.xpath("/html/body/div[2]/div/div/form/div/div/input[1]")).click();
		}
		
		driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
		//Alert alert=driver.switchTo().alert();
		//alert.accept();
		String ActTit="";
		String ExpTit = "Your Account Has Been Created!";
		
		WebElement Head = driver.findElement(By.xpath("/html/body/div[2]/div/div/h1"));
		ActTit = Head.getText();
		
		if (ActTit.contentEquals(ExpTit)) {
			System.out.println("Title verified");
		}
		else {
			System.out.println("Title not verified");
		}
		
		System.out.println("Test passed");
		
	}
	
	
	@After
	public void close()
	{
		
		driver.quit();
	}
	
}