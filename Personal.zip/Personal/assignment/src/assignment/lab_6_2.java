/**
 * 
 */
package assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

/**
 * @author nbobde
 *
 */
public class lab_6_2 {

	WebDriver driver;
	SoftAssert softAssert= new SoftAssert();
	
	@BeforeTest
	public void openBrowser() throws InterruptedException{
		
		driver.get("http://demo.opencart.com/");
		Thread.sleep(2000);
		driver.findElement(By.className("caret")).click();
		driver.findElement(By.xpath("/html/body/nav/div/div[2]/ul/li[2]/ul/li[1]/a")).click();
		
		driver.findElement(By.id("input-firstname")).sendKeys("Nilesh");
		driver.findElement(By.id("input-lastname")).sendKeys("Bobde");
		driver.findElement(By.id("input-email")).sendKeys("ramvan@gmail.com");
		driver.findElement(By.id("input-telephone")).sendKeys("8007410433");
		
		driver.findElement(By.id("input-address-1")).sendKeys("Kalmeshwar");
		driver.findElement(By.id("input-city")).sendKeys("Nagpur");
		driver.findElement(By.id("input-postcode")).sendKeys("441501");
		
		WebElement Country = driver.findElement(By.id("input-country"));
		Select select1 = new Select(Country);
		select1.selectByValue("99");
		
		Thread.sleep(2000);
		
		WebElement State = driver.findElement(By.id("input-zone"));
		Select select2 = new Select(State);
		select2.selectByValue("1493");
		
		driver.findElement(By.id("input-password")).sendKeys("ram8007410433");
		driver.findElement(By.id("input-confirm")).sendKeys("ram8007410433");
		
		driver.findElement(By.xpath("/html/body/div[2]/div/div/form/fieldset[4]/div/div/label[1]/input")).click();
		
		String title=driver.getTitle();
		
		Assert.assertEquals(title, "The OpenCart demo store");
	}
	
	@Test
	public void testCaseOne() throws InterruptedException
	{
		WebElement Head = driver.findElement(By.xpath("/html/body/div[2]/div/div/h1"));
		Head.getText();
			
		Assert.assertEquals(Head, "Your Account Has Been Created!");
			softAssert.assertAll();
	}
	
	@AfterTest
	public void closeBrowser()
	{
		driver.quit();
	}
}
